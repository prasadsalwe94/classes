package com.java.inquries.entities;

public class Batch {

}
