package com.java.inquries.service;

public interface StudentService {

}
