package com.scp.java.demo.online.food.delivery;

public class FoodServices {
	
	static public void placeOrder(Hotel hotel,String whichMenu) {
		Menus menus[] = hotel.getMenus();
		for (Menus menu : menus) {
			if(menu.getMenuName().equals(whichMenu)) {
				System.out.println("Menu Avaiable..!"+menu);
				return;
			}
		}
		System.out.println(whichMenu +",Menu cannot be served currently..!");
	}
	
	public void chooseMenus() {
		
	}
	
	public void cancelOrder() {
		
	}
	
	public void refund() {
		
	}
	
}
