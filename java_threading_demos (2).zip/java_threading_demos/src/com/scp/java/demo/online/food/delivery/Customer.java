package com.scp.java.demo.online.food.delivery;

public class Customer {
	private int custId; // -2^31 to 2^31-1 -- >0
	private String custName;
	private Address custAddress;
	private Account account;
	private String email;
	private GenderType gender;	//MALE/FEMALE/null
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Address getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(Address custAddress) {
		this.custAddress = custAddress;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public GenderType getGender() {
		return gender;
	}
	public void setGender(GenderType gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "\n Customer [custId=" + custId + ", custName=" + custName + ", custAddress=" + custAddress + ", account="
				+ account + ", email=" + email + ", gender=" + gender + "]";
	}
	public Customer(int custId, String custName, Address custAddress, Account account, String email,
			GenderType gender) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custAddress = custAddress;
		this.account = account;
		this.email = email;
		this.gender = gender;
	}
	public Customer() {
		super();
	}
	
	
}


enum GenderType{
	MALE,
	FEMALE
}