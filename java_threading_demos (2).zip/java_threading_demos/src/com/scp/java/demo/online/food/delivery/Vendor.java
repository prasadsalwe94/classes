package com.scp.java.demo.online.food.delivery;

/**
 * POJO -- plain old java object
 * 	--> which has only properties  along with getters/setters
 * 
 * @author Lenovo
 *
 */
public class Vendor {
		private int vendorId;
		private String vendorName;
		private double deliveryCharges;
		private Account account;
		public int getVendorId() {
			return vendorId;
		}
		public void setVendorId(int vendorId) {
			this.vendorId = vendorId;
		}
		public String getVendorName() {
			return vendorName;
		}
		public void setVendorName(String vendorName) {
			this.vendorName = vendorName;
		}
		public double getDeliveryCharges() {
			return deliveryCharges;
		}
		public void setDeliveryCharges(double deliveryCharges) {
			this.deliveryCharges = deliveryCharges;
		}
		public Account getAccount() {
			return account;
		}
		public void setAccount(Account account) {
			this.account = account;
		}
		@Override
		public String toString() {
			return "Vendor [vendorId=" + vendorId + ", vendorName=" + vendorName + ", deliveryCharges="
					+ deliveryCharges + ", account=" + account + "]";
		}
		public Vendor(int vendorId, String vendorName, double deliveryCharges, Account account) {
			super();
			this.vendorId = vendorId;
			this.vendorName = vendorName;
			this.deliveryCharges = deliveryCharges;
			this.account = account;
		}
		public Vendor() {
			super();
		}
		
		
}

/**
	tostring --> object representation
	setter --> to set restricted values
	getter --> to retrive values
	constructor -->
			no-arg -- default values initializations
			param --> to initialize multiple fields once
*/