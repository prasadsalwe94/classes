package com.scp.java.demo.online.food.delivery;

public class Account {
	private int accNo;
	private double accBalance;
	private AccountTypes accType;		//saving/current [predefined constants]
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(int accNo, double accBalance, AccountTypes accType) {
		super();
		this.accNo = accNo;
		this.accBalance = accBalance;
		this.accType = accType;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}
	public AccountTypes getAccType() {
		return accType;
	}
	public void setAccType(AccountTypes accType) {
		this.accType = accType;
	}
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accBalance=" + accBalance + ", accType=" + accType + "]";
	}

	
	

}


enum AccountTypes{ // predefined values --> S/C
	SAVING,
	CURRENT
}