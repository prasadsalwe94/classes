package com.scp.java.demo.online.food.delivery;

import java.util.Arrays;

public class StartApp {
	
	
	//hold pr rahega --> 
			// will resume this - once we complete types of methods
			// looping concepts...
	public static void main(String[] args) {
		DummyData d1 = new DummyData();
		
		//System.out.println(Arrays.toString(DummyData.customers));
		//System.out.println("***************************");
		//System.out.println(Arrays.toString(DummyData.hotels));
		
		FoodServices.placeOrder(DummyData.hotels[1], "Paneer14");
	}
}
/**
	Types of methods
	Loopings -->

*/