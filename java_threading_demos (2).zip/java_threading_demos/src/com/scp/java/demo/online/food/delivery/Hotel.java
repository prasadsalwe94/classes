package com.scp.java.demo.online.food.delivery;

import java.util.Arrays;

public class Hotel {
	private int hotelId;
	private String hotelName;//ABC		PQRS
	private Address hotelAddress;
	private Account hotelAccount;
	private Menus[] menus = new Menus[5];
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public Address getHotelAddress() {
		return hotelAddress;
	}
	public void setHotelAddress(Address hotelAddress) {
		this.hotelAddress = hotelAddress;
	}
	public Account getHotelAccount() {
		return hotelAccount;
	}
	public void setHotelAccount(Account hotelAccount) {
		this.hotelAccount = hotelAccount;
	}
	public Menus[] getMenus() {
		return menus;
	}
	public void setMenus(Menus[] menus) {
		this.menus = menus;
	}
	@Override
	public String toString() {
		return "\n Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelAddress=" + hotelAddress
				+ ", hotelAccount=" + hotelAccount + ", menus=" + Arrays.toString(menus) + "]";
	}
	public Hotel(int hotelId, String hotelName, Address hotelAddress, Account hotelAccount, Menus[] menus) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelAddress = hotelAddress;
		this.hotelAccount = hotelAccount;
		this.menus = menus;
	}
	public Hotel() {
		super();
	}
	
	
}


/**
	int n1 = 1; // 4 byte
	int n2 = 2;	// 4 bytes
	int n3 = 3; // 4 bytes
	
	Array --->
			collection of homo data elements --> similar type
			fixed in size --> 
			need to define size in advance.
			cannot grow/shrink up at runtime.
			can hold primitives/objects
			Array itself objects-->
					we can use properties of array.
					
	
	int numbers[] = new int[3];
	numbers[0]=1;
	numbers[1]=2;
	numbers[2]=3;
	
	// to hold metadata --> additional information abt data
	int numbers[] = new int[3]; //12bytes+ contigous blocks allocates
	numbers[0]=1;
	numbers[1]=2;
	numbers[2]=3;
	
	
	int numbers[] = {1,2,3};
	


*/