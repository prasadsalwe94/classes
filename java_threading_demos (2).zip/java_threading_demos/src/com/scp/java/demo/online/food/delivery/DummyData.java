package com.scp.java.demo.online.food.delivery;

public class DummyData {
	static Hotel hotels[] = new Hotel[2]; //2
	static Customer customers[] = new Customer[2];//2
	
	static {
		
		Menus menus1[] = new Menus[5];
		menus1[0] = new Menus(44,"Paneer1",423.0);
		menus1[1] = new Menus(45,"Paneer2",495.0);
		menus1[2] = new Menus(46,"Paneer3",255.0);
		menus1[3] = new Menus(47,"Paneer4",335.0);
		menus1[4] = new Menus(48,"Paneer5",222.0);
		Hotel h1 = new Hotel(991,"ABCD",
					new Address("Katraj,Pune","MH",112233),
					new Account(112233,10000.00,
					AccountTypes.CURRENT),
					menus1);
		
		
		Menus menus2[] = new Menus[5];
		menus2[0] = new Menus(23,"Paneer11",523.0);
		menus2[1] = new Menus(323,"Paneer12",695.0);
		menus2[2] = new Menus(44,"Paneer13",763.0);
		menus2[3] = new Menus(4237,"Paneer14",345.0);
		//menus2[4] = new Menus(45,"Paneer15",534.0);
		Hotel h2 = new Hotel(992,"XXXX",
					new Address("Swargate,Pune","MH",112233),
					new Account(112233,25000.00,
					AccountTypes.CURRENT),
					menus2);
		
		
		hotels[0] = h1;
		hotels[1] = h2;
		
		Customer customer1 = new Customer(6661, "Mrs. XXX", 
				new Address("Pune1","MH", 111222),
				new Account(12122,2999.23, AccountTypes.SAVING),
				"abc@gmail.com", GenderType.FEMALE);
		
		Customer customer2 = new Customer(6662, "Mr. YYY", 
				new Address("Pune2","MH", 441222),
				new Account(12131,12999.23, AccountTypes.SAVING),
				"pqrs@gmail.com", GenderType.MALE);
		customers[0] = customer1;
		customers[1] = customer2;
	}
}
