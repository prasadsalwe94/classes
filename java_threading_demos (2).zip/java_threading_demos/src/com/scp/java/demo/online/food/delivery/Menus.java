package com.scp.java.demo.online.food.delivery;

public class Menus {
	private int menuId;
	private String menuName;
	private double menuPrice;
	@Override
	public String toString() {
		return "Menus [menuId=" + menuId + ", menuName=" + menuName + ", menuPrice=" + menuPrice + "]";
	}
	public Menus(int menuId, String menuName, double menuPrice) {
		super();
		this.menuId = menuId;
		this.menuName = menuName;
		this.menuPrice = menuPrice;
	}
	public Menus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public double getMenuPrice() {
		return menuPrice;
	}
	public void setMenuPrice(double menuPrice) {
		this.menuPrice = menuPrice;
	}
	
	
}
