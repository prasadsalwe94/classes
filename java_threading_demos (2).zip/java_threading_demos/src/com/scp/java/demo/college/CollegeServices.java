package com.scp.java.demo.college;

public class CollegeServices {

	public void publishResults() {
		
	}
	
	public void conductExams() {
		
	}
	
}
