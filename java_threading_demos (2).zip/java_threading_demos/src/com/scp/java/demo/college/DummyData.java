package com.scp.java.demo.college;

public class DummyData {

}
