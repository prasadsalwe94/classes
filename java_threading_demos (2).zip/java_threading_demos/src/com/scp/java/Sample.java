package com.scp.java;

import java.util.Scanner;

public class Sample {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number : ");
		int num = sc.nextInt();
		//single condition --> 
				// step by step --> started from first --> till true
				// default condition --> else 
		
		if(num==0) {
			System.out.println("U entered Zero Number -Invalid Marks");
		}else if(num>0 && num<40) {
			System.out.println("Failed");
		}else if(num>40 && num<60) {
			System.out.println("Second Class");
		}else if(num>=60 && num<80) {
			System.out.println("First Class");
		}else if(num>=80 && num<=100) {
			System.out.println("Merit");
		}else {
			System.out.println("Invalid Marks..!");
		}
	}
}

/***
 * public ---> java calls our main method from --. other package
 * static ---> 
 * 				memory will be given at the time of class loading
 * 				no need to create instance of this class--> java can directly call 
 * 				a main method with help of class name
 * void   --->	
 * 				java doesnt expect any return value from your main method
 * 				main is first method loaded into thread stack -->
 * main   ---> 
 * 				meaningful ---> decision-- at the java--> decision-->
 *				main - design level decision --. we are using java-- not developing 				
 * 
 *string array -->
 *				string ---> is a universal type	
 *				string can hold -- number/boolean/double/int/
 * 
 */
