package com.scp.java.demos;

public class StartApp {
		public static void main(String[] args) {
			
			Address adr1 = new Address("S-Pune","MH",12821,"Ganpati Temple");
			Person p1 = new Person(101,"ABCD", 20, adr1);
			
			Address adr2 = new Address("K-Pune","MH",12821,"Ganpati Temple");
			Student st1 = new Student(991,"YYYY",22, adr2);	// only person
			
			Address permAdr = new Address("Mumbai","MH",12821,"Ganpati Temple");
			Address tempAdr = new Address("H-Pune","MH",12821,"Ganpati Temple");
			Student st2 = new Student(991,"YYYY1",23, permAdr,2618.23, tempAdr);
			
			Address adr3 = new Address("KT-Pune","MH",12821,"Ganpati Temple");
			Employee e1 = new Employee(771, "XXXX", 30, adr3);
			

			Address adr4 = new Address("KO-Pune","MH",12821,"Ganpati Temple");
			Employee e2 = new Employee(772, "XXXX1", 30, adr4);
			
			
			
			// 6address objects
			// EMP - 2
			//STUDENT -  2
			// PERSON -- 1
			
			System.out.println(e1);
			
			
		}
}
