package com.scp.java.demos;

/**
 * 
 * primitivies and static --> 
 * 					are not the object orieneted concepts.
 * 
 * Java is pure object oriented lang -.
 * 		With an exceptional cases - primitivies/static -->
 * 			java is a pure object oriented programming lang.
 * 
 * 
 * Encapsulation -->
 * 		implicit concept in java--> must
 * 		no extra efforts--. which is default one--
 * 		as we write a class --. encapsulation.
 * Inheritance -->
 * 		Emp and student --> madhe common -- properties
 * 						Person
 * 			Person		
 * 	Student			Employee
 * 
 * Class --> Yes
 * Object --> We are going to create object-->
 * 
 * 
 * class -->
 * 			properties -- private
 * 			getter/setter -- to apply business validations
 * 			tostring --> for object representations
 * 			constructors --> to initialize object proeprties.
 * 
 * 
 * super --> always provides an access to parent object fields.
 * this --> always provides an access to current object fields
 * 
 * 
 * @author Lenovo
 *
 */
public class Person {
	private int personId;
	private String personName;
	private int personAge;
	private Address personAddress;
	
	
	static {
		System.out.println("Static Block -- Person");
	}
	
	{
		System.out.println("Instance Block - Person");
	}
	
	public Person(int personId, String personName, int personAge, Address personAddress) {
		this.personId = personId;
		this.personName = personName;
		this.personAge = personAge;
		this.personAddress = personAddress;
		System.out.println("Person cha --> Param Constructor");
	}
	
	
	public Person() {
		System.out.println("Person cha -- NoArg Constructor");
	}



	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personName=" + personName + ", personAge=" + personAge
				+ ", personAddress=" + personAddress + "]";
	}
	public Address getPersonAddress() {
		return personAddress;
	}
	public void setPersonAddress(Address personAddress) {
		this.personAddress = personAddress;
	}
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public int getPersonAge() {
		return personAge;
	}
	public void setPersonAge(int personAge) {
		this.personAge = personAge;
	}
	
	
	
}
					

class Employee extends Person{
	private double empSalary;
	private String empEmail;
	static private String companyName;
	
	static {
		System.out.println("Static Block -- Employee");
	}
	
	{
		System.out.println("Instance Block - Employee");
	}
	
	public double getEmpSalary() {
		return empSalary;
	}



	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}



	public String getEmpEmail() {
		return empEmail;
	}



	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}



	public static String getCompanyName() {
		return companyName;
	}



	public static void setCompanyName(String companyName) {
		Employee.companyName = companyName;
	}



	public Employee() {
		System.out.println("Emp - NO Arg");
			
	}



	public Employee(int personId, String personName, int personAge, Address personAddress) {
		super(personId, personName, personAge, personAddress);
		System.out.println("Param Employee -- without empfields");
	}



	public Employee(int personId, String personName, int personAge, Address personAddress, double empSalary,
			String empEmail) {
		super(personId, personName, personAge, personAddress);
		this.empSalary = empSalary;
		this.empEmail = empEmail;
		System.out.println("Param  Employee -- with Emp fields");
		
	}



	//object represetations--> instead of printing--memory address
	@Override
	public String toString() {
		return "Employee "
				+ "[empSalary=" + empSalary + 
				", empEmail=" + empEmail + "]" + super.toString();
	}
	
	
}

class Student extends Person{
	static private String collegeName;
	private double studFees;
	private Address tempHostelAddress;
	
	static {
		System.out.println("Static Block -- Student");
	}
	
	{
		System.out.println("Instance Block - Student");
	}
	
	@Override
	public String toString() {
		return "Student "
				+ "[studFees=" + studFees + 
				", tempHostelAddress=" + tempHostelAddress + "]" +super.toString();
	}
	public Student(int personId, String personName, int personAge, Address personAddress, double studFees,
			Address tempHostelAddress) {
		super(personId, personName, personAge, personAddress);
		this.studFees = studFees;
		this.tempHostelAddress = tempHostelAddress;
		System.out.println("Param Student --> with Student Fields");
	}
	public Student() {
		super();
		System.out.println("Student no-arg");
	}
	public Student(int personId, String personName, int personAge, Address personAddress) {
		super(personId, personName, personAge, personAddress);
		System.out.println("Param Student -- without stud Fields");
	}
	public static String getCollegeName() {
		return collegeName;
	}
	public static void setCollegeName(String collegeName) {
		Student.collegeName = collegeName;
	}
	public double getStudFees() {
		return studFees;
	}
	public void setStudFees(double studFees) {
		this.studFees = studFees;
	}
	public Address getTempHostelAddress() {
		return tempHostelAddress;
	}
	public void setTempHostelAddress(Address tempHostelAddress) {
		this.tempHostelAddress = tempHostelAddress;
	}
	
	
	
}

// type --> what address means -->
class Address{
	private String city;
	private String state;
	private int pincode;
	private String landmark;
	
	static {
		System.out.println("Static Block -- Address");
	}
	
	{
		System.out.println("Instance Block - Address");
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", pincode=" + pincode + ", landmark=" + landmark + "]";
	}
	public Address(String city, String state, int pincode, String landmark) {
		super();
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.landmark = landmark;
		System.out.println("Param Address --> Param");
	}
	public Address() {
		System.out.println("Address - NO Arg");
	}
	
	
	
	
}

	/**
	 * 					Person
	 * Employee							Student
	 * 
	 * 
	 * 
	 * 
	 * 
	 */

