package com.scp.java.thread;

import java.util.concurrent.TimeUnit;

public class Sample {
	
	public static void main(String[] args) throws InterruptedException {
		for(int i=0;i<10;i++) {
			System.out.println("Value -->" +i);
			TimeUnit.SECONDS.sleep(1);
		}
		System.out.println("FOr Loop COmpleted");
		System.exit(0);
		/**
		 * 0 -->  everything is okay --> simple stop java process.
		 * 			shut down -> wait till the time-- all task to be finished/stopped
		 * +ve --> i am intertested to close all resources-- which is been used 
		 * 			by java and stop java process --> forceful.
		 * 			shut down -- end all --end all--> forceful
		 * -ve --> abnormal termination
		 * 			Laptop -- power button ko hi-- press -> all resources abnormally stops functioning
		 * 
		 */
		System.out.println("Main Method Completed..!");
	}
}
