package com.scp.java.thread.basics;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class ProducerConsumerImpl {
	
	public static void main(String[] args) {
		// not a synchro
		List<Car> inventory1 = new ArrayList<Car>(); // main --> shared resources --among pr2/cn
		
		Producer p1 = new Producer("Producer1",inventory1); // p1 -- waiting
		Producer p2 = new Producer("Producer2",inventory1); // p2  -->waiting
		Producer p3 = new Producer("Producer3",inventory1); // p3	 --> notify
		
		Consumer c1 = new Consumer("Consumer1",inventory1);// c1	-> waiting
		
		p1.start();
		p2.start();
		p3.start();
		c1.start();
		
		//wait--notify--notityall --> for interthread communication on shared resources
		//that is the reason these methods kept inside object class-- instead thread class.
		
		
//pinventory -- is the shared resource among threads -->
				/**				
				 * 				timeinterval
				 * 				notify			
				 * wait			wait(ms)		wait(ms,ns)---> object class
				 * notify		notifyall 	-->   object class
				 * --randomly any waiting walya thread la awake--> same resource
				 * notifyall --> all waiting madhlya threads la awake--same resource
				 */
	}
}

class Car implements Comparable<Car>{
	private int carId;
	private String carModel;
	private double carPrice;
	public Car(int carId, String carModel, double carPrice) {
		super();
		this.carId = carId;
		this.carModel = carModel;
		this.carPrice = carPrice;
	}
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "\n [carId=" + carId + ", carModel=" + carModel + ", carPrice=" + carPrice + "]";
	}
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public double getCarPrice() {
		return carPrice;
	}
	public void setCarPrice(double carPrice) {
		this.carPrice = carPrice;
	}
	@Override
	public int compareTo(Car o) {
		return -(int)(this.carPrice - o.carPrice);	// whichever car id is larger--will be removed first.
	}
	/**
	 * 		int - int 	--> 	0 			--> both objects are equal
	 * 							+ve			--> first one is larger
	 * 							-ve			--> first one is smaller
	 */		
	
}


class Producer extends Thread{
	List<Car> pinventory;
	static int count = 100;
	public Producer(String name,List<Car> inventory) {
		super(name);
		this.pinventory = inventory;
	}
	
	synchronized static public Car manufactureCar() {
		try {
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException e) {
		}
		count = count + 1;
		return new Car(count, "AAAA"+count, ThreadLocalRandom.current().nextInt(10000,30000));
	}
	
	@Override
	public void run() { // instance method --> Producer  p1 p2
		
		while(true) {
			synchronized (pinventory) {
				if(pinventory.size()==10) {
					System.out.println(Thread.currentThread().getName()+" waiting");
					pinventory.notify(); // waiting madhe jo koni asel tr-- notify
					try {
					pinventory.wait();	// whichever thread is calling this stmt
					} catch (InterruptedException e) {
					} 
				}else {
					pinventory.add(manufactureCar());
					System.out.println(Thread.currentThread().getName()+":("+pinventory.size()+")"+pinventory);
				}
				}
			}
	}
}

class Consumer extends Thread{
	List<Car> cinventory;
	
	public Consumer(String name,List<Car> inventory) {
		super(name);
		this.cinventory = inventory;
	}
	
	@Override
	public void run() {
		while(true) {
			synchronized (cinventory) {
				while(cinventory.size()>0) {
					try {
						TimeUnit.SECONDS.sleep(3);
					} catch (InterruptedException e) {
					}
					Car car = cinventory.remove(0);
					System.out.println(Thread.currentThread().getName() +":"+car);
				}
				System.out.println("Notified to Producer and Consumer is in waiting State..!");
				cinventory.notify(); // producer la notify
				try {
					cinventory.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
