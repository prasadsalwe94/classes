package com.scp.java.thread.basics;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

// random hundred numbers pahijet..
public class SingleThreadApp {
		
		static List<Integer> numbers = new ArrayList<Integer>(); //array[0]=10
		
		static public void generateRandomNumbers(int n) { //task-1000 random num
			for(int i=0;i<n;i++) {
				System.out.println(i);
				//int num = ThreadLocalRandom.current().nextInt(1,9999999);
				//numbers.add(i);//generated num kuthe place kela jael--> list madhe
			}
		}
	
		public static void main(String[] args) {
			System.out.println("Inside Main method");
			long startTime = System.currentTimeMillis();//timer start kela
			generateRandomNumbers(200);
			long endTime = System.currentTimeMillis(); //end time
			System.out.println(numbers);
			System.out.println("That took " + (endTime - startTime) + " milliseconds");
			System.out.println("Main method Completed..");
		}
}
/**
 * start --->		
 * run  --->		run method override
 * 
 * 
 * what if start method la override --> 
 * 					no new thread creation--> start responsiblities-- override..
 * 					--> new thread register nah honar -->
 * 					--> thread will get task.
 * 
 * what if directly called to run method instead of start
 * 			--> execution will happen normally --> main thread chya--> no new thread
 * 				will be created -- run method will be executed--> normally as other instance method.
 * 			
 *	A implements  Runnable -->run method mandatory -->task
 *							--> here we have one more chances to extend any other class
 *  						FIrst of all - 
 *  						A a  = new A()
 *  						Thread t1 = new Thread(a) // run
 *  						t1.start()
 *  						Thread t2 = new Thread(a) // run
 *  						t2.start()
 *  					one object - same object --> multiple thread instances-->
 *  					every thread instance will start.
 *  A extends	Thread	   --> ideally run method override karto--task
 *  						--> you cannot extend any other class
 * 						A  a1 = new A();
 * 						a1.start()
 * 						
 * 						A  a2 = new A(); // everytime u need to create an instance of ur class--then only u can start a thread
 * 						a2.start() ?? -- Error
 * 							
 * 						one object- one task - one thread
 * 
 * 	sleep vs wait
 * 			-->Sleep is a method of Thread class --> static method
 * 			--> wait is a method of object class ---> instance method
 * 			
 * 			--> sleep --> Timed waiting
 * 			--> wait --> timed or io or combine
 * 			--> wait(),(ms),(ms,ns)
 * 
 * 			--> sleep --> resources sobt kuthe jaun waiting madhe jate
 * 						-> deadlock chec chances 
 * 								deadlock --??
 * 										can be take preventive actions
 * 										can be detected in a system
 * 										cannot be resolved.. once occurred
 * 											
 * 			--> wait ---. resources release karun waiting madhe jate
 * 
 * 	Thread.sleep(seconds)
 * 	Object.wait()
 * 	Object.wait(ms)
 * 	Object.wait(ms,ns)
 * 
 * 
 * 
 * ---> go thru --> kara --
 * 				how to create thread
 * 				thread lifecycle
 * 				run/start/join/sleep/yield
 * 			
 * 			join --> 
 * 						t1.join()	--> main chya context madhe -->
 * 											first t1 and then main
 * 						Thread.yield()	--> main chya context madhe 
 * 											main --> will surrender --> core main
 * 											same priority cha-- queue --.
 * 											main cha place gheu shkto-->
 * 											karaycha ki nah -- os -->
 * 
 * 
 * 			Thread vs Process
 * 			run vs start
 * 			join vs yield
 * 			sleep vs wait
 * 			runnable vs thread
 * 			run vs call
 * 			thread lifecycle
 * 			singlethread vs multithreaded
 * 			deamon thread
 * 			green thread
 * 			suspend vs destroy
 * 			Thread constructors
 * 			what if run method called instead start
 * 			what if start method overriden instead of run
 * 			
 */
