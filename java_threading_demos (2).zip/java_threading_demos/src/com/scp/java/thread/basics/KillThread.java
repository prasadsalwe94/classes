package com.scp.java.thread.basics;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class KillThread {
	public static void main(String[] args) {
		Ax x1 = new Ax();
		Thread t1 = new Thread(x1);
		t1.start();
		
		Scanner sc = new Scanner(System.in);
		
	}
}

class Ax implements Runnable{
	boolean flag = true;

	@Override
	public void run() {
		while(true) {
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(ThreadLocalRandom.current().nextInt(1, 1000));
		}
	}
	
	
	
}