package com.scp.java.thread.basics;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import com.sun.org.apache.bcel.internal.generic.DALOAD;
public class QueueImplementation {
	public static void main(String[] args) {
		
		DelayQueue<NewCar> inventory1 = new DelayQueue<NewCar>();
		Producer1 p1 = new Producer1("P1",inventory1);
		Consumer1 c1 = new Consumer1("C2",inventory1);
		p1.start();
		c1.start();
		//c2.start();
	}
}

class NewCar implements Delayed{
	
	String name;
	int time;
	
	// Constructor of DelayObject 
    public NewCar(String name, int delayTime) 
    { 
        this.name = name; 
        this.time  = delayTime;
    } 
  
    
    @Override
	public String toString() {
		return "\n [name=" + name + ", time=" + time + "]";
	}


	// Implementing getDelay() method of Delayed 
    @Override
    public long getDelay(TimeUnit unit) 
    { 
        int diff = (int) (time - System.currentTimeMillis()); 
        return unit.convert(diff, TimeUnit.SECONDS); 
    } 
  
    // Implementing compareTo() method of Delayed 
    @Override
    public int compareTo(Delayed obj)  // - + 0
    { 
        if (this.time < ((NewCar)obj).time) { 
            return 1; 
        } 
        if (this.time > ((NewCar)obj).time) { 
            return -1; 
        } 
        return 0; 
    }

	public static NewCar getCar() {
		return new NewCar("AAA"+ThreadLocalRandom.current().nextInt(),ThreadLocalRandom.current().nextInt(1,100));
	} 
	
	
	
}

class Producer1 extends Thread{
	DelayQueue<NewCar> pinventory;
	public Producer1(String name,DelayQueue<NewCar> inventory) {
		super(name);
		this.pinventory = inventory;
	}
	
	@Override
	public void run() {
		while(true) {
			String name = Thread.currentThread().getName();
			NewCar car = NewCar.getCar();
			try {
				TimeUnit.SECONDS.sleep(1);
				pinventory.put(car);
				System.out.println(name+"Manufactured Car is -->"+pinventory.size()+":"+pinventory);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}catch(IllegalStateException e){
					System.out.println("Capacity full..."+car);
			}
		}
	}
}

class Consumer1 extends Thread{
	DelayQueue<NewCar> cinventory;
	public Consumer1(String name,DelayQueue<NewCar> inventory) {
		super(name);
		this.cinventory = inventory;
	}
	@Override
	public void run() {
		
		while(true) {
			String name = Thread.currentThread().getName();
			try {
				TimeUnit.SECONDS.sleep(5);
				NewCar car = cinventory.take();
				System.out.println(name +"Consumed Car -->" +car );
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}