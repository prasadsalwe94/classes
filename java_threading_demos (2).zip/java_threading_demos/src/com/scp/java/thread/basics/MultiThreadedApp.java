package com.scp.java.thread.basics;

import java.util.concurrent.Callable;

public class MultiThreadedApp {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Main method started..");
		
		
		A a1 = new A(0,100); // object created for --> A class --> A class is a child of Runnable.
		A a2 = new A(100,200);
		//A a3 = new A(500000,750000);
		//A a4 = new A(750000,1000000);
		
		Thread t1 = new Thread(a1,"T1");	// a -- chya run madhe.
		Thread t2 = new Thread(a2,"T2");
		//Thread t3 = new Thread(a3,"T3");
		//Thread t4 = new Thread(a4,"T4");
		long startTime = System.currentTimeMillis();//timer start kela
		t1.start();
		t2.start();
		//t3.start();
		//t4.start();
		
		t1.join(); // main chya context madhe --> main will till t1 finishes.
		t2.join();
		//t3.join();
		//t4.join(); // 4L
		
		long endTime = System.currentTimeMillis(); //end time
		System.out.println("That took " + (endTime - startTime) + " milliseconds");
		
		//System.exit(0);
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getPriority());
		System.out.println(Runtime.getRuntime().availableProcessors());
		System.out.println("Main completed..");
	}
}


class A implements Runnable{
	int startPoint = 0;
	int endPoint = 0;
	public A (int start,int end) {
		this.startPoint = start;
		this.endPoint = end;
	}
	@Override
	public void run() {				// holds task for a thread. --> work for Worker[Thread]
		System.out.println(Thread.currentThread().getName() +"Started");
		for(int i=startPoint;i<endPoint;i++) {
			System.out.println(Thread.currentThread().getName() +":"+i);
		}
		System.out.println(Thread.currentThread().getName() +" Finished");
	}
	
}

class B extends Thread{
	int startPoint = 0;
	int endPoint = 0;
	public B(int start,int end) {
		this.startPoint = start;
		this.endPoint = end;
	}
	@Override
	public void run() {				// holds task for a thread. --> work for Worker[Thread]
		System.out.println(Thread.currentThread().getName() +"Started");
		for(int i=startPoint;i<endPoint;i++) {
			System.out.println(Thread.currentThread().getName() +":"+i);
		}
		System.out.println(Thread.currentThread().getName() +" Finished");
	}
	
}


class C implements Callable<Integer>{
	int startPoint = 0;
	int endPoint = 0;
	public C(int start,int end) {
		this.startPoint = start;
		this.endPoint = end;
	}
	
	@Override
	public Integer call() throws Exception {
		System.out.println(Thread.currentThread().getName() +"Started");
		for(int i=startPoint;i<endPoint;i++) {
			System.out.println(Thread.currentThread().getName() +":"+i);
		}
		System.out.println(Thread.currentThread().getName() +" Finished");
		return null;
	}
	
}