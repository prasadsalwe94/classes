package com.scp.java.basic;

public class C {


	//variables ---> instance   static   local
	int cvar1; /// object level
	static int cvar2; // class level
	
	public C(){
		System.out.println("No-Arg Constructor -C class cha");
	}
	
	public C(int a){  // params --> local variables
		int num = 10; // local variables --> scope is limitied to A--> {}
		System.out.println("Param Constructor -C class cha");
	}
	static{
		System.out.println("C -- Static Block execution ");
	}
	{
		System.out.println("C -- Instance Block execution ");
	}
	
	public void p1() {
		System.out.println("Instance Method -- C");
	}
	
	static public void p2() {
		System.out.println("static Method -- C");
	}



}
