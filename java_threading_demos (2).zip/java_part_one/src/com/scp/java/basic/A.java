package com.scp.java.basic;

public class A {
	//variables ---> instance   static   local
	int avar1; /// object level
	static int avar2; // class level
	
	public A(){
		System.out.println("No-Arg Constructor -A class cha");
	}
	
	public A(int a){  // params --> local variables
		int num; // local variables --> scope is limitied to A--> {}
		System.out.println("Param Constructor -A class cha");
		System.out.println(avar1);
		System.out.println(avar2);
	}
	static{
		System.out.println("A -- Static Block execution ");
	}
	{
		System.out.println("A -- Instance Block execution ");
	}
	
	public void m1() {
		System.out.println("Instance Method -- A");
	}
	
	static public void m2() {
		System.out.println("static Method -- A");
	}
}
