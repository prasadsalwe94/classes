package com.scp.java.basic;

public class AppStart {
	static{
		System.out.println("Static block of Appstart");
	}
	{
		System.out.println("Instance block of Appstart");
	}
	
	public static void main(String[] args) {
		System.out.println("Inside AppStart Main method");
		Employee e1 = new Employee();	// No-Arg
		Employee e2 = new Employee();	// No-Arg
		
		System.out.println(e1);
		System.out.println(e2);
	}
}
