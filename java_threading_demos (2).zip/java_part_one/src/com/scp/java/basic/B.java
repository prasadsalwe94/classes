package com.scp.java.basic;

public class B {

	//variables ---> instance   static   local
	int bvar1; /// object level
	static int bvar2; // class level
	
	public B(){
		System.out.println("No-Arg Constructor -B class cha");
	}
	
	public B(int a){  // params --> local variables
		int num = 10; // local variables --> scope is limitied to A--> {}
		System.out.println("Param Constructor -B class cha");
	}
	static{
		System.out.println("B -- Static Block execution ");
	}
	{
		System.out.println("B -- Instance Block execution ");
	}
	
	public void n1() {
		System.out.println("Instance Method -- B");
	}
	
	static public void n2() {
		System.out.println("static Method -- B");
	}


}
