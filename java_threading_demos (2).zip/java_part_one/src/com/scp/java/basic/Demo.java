package com.scp.java.basic;

public class Demo {
		//every variable is a ref variable - False
		//every ref variable is a variable --True -> broader context-variable
	public static void main(String[] args) {
		System.out.println("Inside main...");
		A a1 = new A();  // a1 - is ref to the object--> object is on memory - heap
		B b1 = new B();
		C c1 = new C();
		A a2 = new A();
		B b2 = new B();
		C c2 = new C();
		System.out.println("Main method Completed");
	}
}
