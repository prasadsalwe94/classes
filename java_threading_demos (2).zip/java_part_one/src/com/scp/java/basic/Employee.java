package com.scp.java.basic;

//outer --> class
public class Employee {
	String name;   // nonprimitive --> String--java defined
	int empId;	  // int --> primitive--fix --4 byte
	String empAddress;	// nonprimitive string- java defined
	int empAge;		// int --primitive -- fix -- 4 byte
	String empEmail;	// nonprimitive string
	String empRole;		//nonprimitive string
	
	static{
		System.out.println("Static block of Employee");
	}
	{
		System.out.println("Instance block of Employee");
	}
	
	// default constructor -->no-arg ---> values --> default values
	public Employee() {
	}
	
	
	
}

/**

	default --> within same package
	private	--> within same class
	protected --> within same package and outside package too but shud 
					a child class
	public	--> anywhere in same project.
						
						DataTypes
	Primitives[only java]				NonPrimitives[Java/dev as per business requirements]
		Numeric
			Integral
				--byte-
				--short
				--int
				--long
			FLoating
				--float
				--doublt
		Logical
			--boolean
		Character
			--char
	
Primitives					
[only individual value]		
				Wrappers[objects-->class-->methods/variables/properties]

 byte 	0		Byte
 short	0		Short
 int	0		Integer
 char	space	Character
 float	0.0f	Float
 double	0.0d	Double
 booleanfalse	Boolean
					
	
	
		

*/