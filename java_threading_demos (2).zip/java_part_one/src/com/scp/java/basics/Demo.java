package com.scp.java.basics;

public class Demo {

}
