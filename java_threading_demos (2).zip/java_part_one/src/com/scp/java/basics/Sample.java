package com.scp.java.basics;

 class Sample {
	 protected void m2() {
		 
	 }
}

 class OneMore{
	 
 }
/**
 * 
 * Book -- is an idetifier for class
 * isbnumber--authorname ---> variable idenfiers
 * scope -- of class -- default 
 * scope of the variables is the private.
 * 
 * default -- class/variable/methods/constructors --> that element can not be accessed outside the package
 * 
 * 
 * 
 * 
 *  1 java file --> can contain -- maximum -- 1 public class
 *  			--> file may or may not have public class
 *  
 *  1 file can have -- zero or 1 public classes
 *  if file contains - public class--> java says-- that shud be
 *  your filename.java
 *  if file contains -- no public class--> in that case
 *  any valid name can be a file name validname.java -- not necessary
 *  that shud from class name.
 *  
 *  main method --> 
 *  			in java is a starting point of program 
 *  execution
 *  
 *  Sample.java
 *  			public class Sample
 *  				private int var1; --> scope is limited to sample class only
 *  				private void m1(){ --> scope is limited to sample class
 *  				}
 *  
 *  			class Book
 *  				main
 *  			class Emp
 *  				main
 */

class Book{				
	private int isbnNumber;
	private String authorName;
	private String bookName;
	private double bookPrice;
	private int bookQty;
	private String bookPublication;
}

class Emp{
	public int empId;		// public primitive int type -- instance variable of emp class
	String empName; //Yash		Yogesh
	private int empSalary;
	protected String empCompany;
	
	//variables
			// 		accessmodifiers datatype identifier;		--> declaration
			// 		accessmodifiers datatype inentifier = value; --> initialization
			// 	variables --> public/protected/private/default 4:1
							
 }


// single line comment

/**

class --> abstract  public  default  final

	public
	protected			4:1
	private
	default
	
	abstract
	final
	static
	strictfp
	transient
	native
	volatile
	synechonized
	


multiline comments
Access modifiers --> scope


*/