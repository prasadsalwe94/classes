package com.scp.java.samples;

import java.util.concurrent.TimeUnit;

public class ThreadingDemo {

	
	public static void main(String[] args) {

		System.out.println(Thread.currentThread().getName()+" ..started \n");
		A a = new A();
		Thread athread = new Thread(a,"AThread");
		B bthread1 =new B("BThread",100);
		B bthread2 =new B("CThread",200);
		B bthread3 =new B("DThread",300);
		B bthread4 =new B("EThread",400);
		B bthread5 =new B("FThread",500);
		
		athread.start();
		bthread1.start();
		bthread2.start();
		bthread3.start();
		bthread4.start();
		bthread5.start();
		System.out.println(Thread.currentThread().getName()+" ..Completed\n");
	}
/**
 * Number of Threads --3
 * 	mainthread --> 
 * 				main method execution
 * 				in  which create two threads and assign thr work
 * 				start those threads -->
 * 					thread.start()-->
 * 								register this thread with Thread Schedular
 * 					
 * whichever threads are inside - operating system thread scheduler--
 * 			which one to pick
 * 			how to pick
 * 			when to pick --> os -->
 * 							resources allocation
 * 							core assign -->
 * 								run method execution will start
 * 								Thread -- Running--			
 * 	Athread
 *  Bthread
 * 
 * 
 */
	
}

class A implements Runnable{

	@Override
	public void run() {
		for(int i=0;i<100;i++) {
			System.out.println(Thread.currentThread().getName() +":" +i);
			
		}
		System.out.println(Thread.currentThread().getName()+" ..Completed\n");
		
	}

}

class B extends Thread{
	int startPoint;
	public B(String name,int count) {
		super(name);
		this.startPoint = count;
	}

	@Override
	public void run() {
		for(int i=startPoint;i<startPoint+100;i++) {
			System.out.println(Thread.currentThread().getName() +":" +i);
			
		}
		System.out.println(Thread.currentThread().getName()+" ..Completed\n");
		
	}
}
