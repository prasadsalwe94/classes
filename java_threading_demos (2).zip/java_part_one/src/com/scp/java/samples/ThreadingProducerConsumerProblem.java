package com.scp.java.samples;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
/**
 * 
 * Bakery Shop -->
 * 		
 * 			Cakes -->
 * 
 *  	Small vendor -->
 *  				10 cakes ---> order - 10 cakes -- sale--
 *  				then again will order 10 cakes order
 *  				then sale those 10
 *  				then order 10 again
 *  		10--producer		---> 10-consume --> 0
 *  		10 -producer 		---> 10-consumer --> 0
 *  		and so on -- infinite
 *  					either -->
 *  			10					 waiting
 *  					notify				start
 *  											consume 
 *  												notify
 *  			start
 *  				10:stop-notify				start:0-->notify
 *  				
 *  	Medium scale
 *  		10 cake order	--> 		consumer --will start
 *  									consuming-->
 *  									75% --> sale zala
 *  									consumer will notify
 * 			producer
 * 				again will match 10	---> 	consumer start ch
 * 						at some point of time --.
 * 			producer		-- always start
 * 					producer --> consumer -- both working.
 * 
 * 		
 * 		larger scale vendor
 * 			continously produce ---> 	continously consumer
 * 						both at the same time
 * 						working 
 * 				no one is going to wait--or notify each other.
 * 
 *
 */
public class ThreadingProducerConsumerProblem {

	public static void takePause(long val) {
		
		try {
			TimeUnit.SECONDS.sleep(val);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
		
	public static void main(String[] args) {
			
			List<Integer> values = new ArrayList<Integer>();
			Producer p1 = new Producer("Producer1", values);
			Consumer c1 = new Consumer("Consumer1", values);
			p1.start();
			c1.start();
		}
}


class Producer extends Thread{
	List<Integer> values;
	public Producer(String name,List<Integer> values) {
		super(name);
		this.values = values;
	}
	
	@Override
	public void run() {
		while(true) {
			synchronized (values) {
				if(values.size()==10) {
					System.out.println("PRODUCER : Notified to consumer.. and going to waiting state");
					values.notify(); // whoever is waiting on values -->
					try {
						values.wait();	// wait for values --> 
					} catch (InterruptedException e) {
						e.printStackTrace();
					} 
				}else {
					int num = ThreadLocalRandom.current().nextInt(1,1000);
					values.add(num);
					System.out.println( Thread.currentThread().getName() +"("+ values.size() +") : "+values);
					ThreadingProducerConsumerProblem.takePause(1);
				}
			}
			
			
		}
	}
}

class Consumer extends Thread{
	List<Integer> values;
	public Consumer(String name,List<Integer> values) {
		super(name);
		this.values = values;
	}
	@Override
	public void run() {
		if(values.isEmpty()) {
			System.out.println("Consumer is waiting for 5 seconds as no elements in list..!");
			ThreadingProducerConsumerProblem.takePause(5);
			synchronized (values) {
				try {
					values.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		while(true) {
			
			synchronized (values) {
				if(values.isEmpty()) {
					System.out.println("CONSUMER : notified to producer and waiting for elements inside list");
					values.notify();
					try {
						values.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}else {
					//int num = ThreadLocalRandom.current().nextInt(0,values.size()-1);
					int x = values.remove(0); // zeroth index cha element wil be removed
					//System.out.println(Thread.currentThread().getName() +" :"+ x +" : "+values);
					
					System.out.println( Thread.currentThread().getName() +"("+ values.size() +") : "+ x +":"+values);
					
					ThreadingProducerConsumerProblem.takePause(3);
				}
			}
			
		
		}
	}
}