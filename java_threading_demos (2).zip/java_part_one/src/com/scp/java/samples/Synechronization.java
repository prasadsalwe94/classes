package com.scp.java.samples;

public class Synechronization {
	
	
	public static void main(String[] args) throws InterruptedException {
		Ax t1 = new Ax(1000,"AThread");
		Bx t2 = new Bx(350,"BThread");
		t1.start();		// 1000 time increment
		t2.start();		// 1000 time decrement
		
		t1.join();
		t2.join();	
		
		// unless t1 and t2 not completing thr tasks--> count will not be printed..
		System.out.println(Util.count); //  expected output -- is zero
		System.out.println(Thread.currentThread().getName() +" Completed..");
	}
	
}

class Util{
	static int count = 0;
	synchronized public static void increment() {  // static method level synechorization
		count++;
	}
	
	synchronized public static void decrement() {
		count--;
	}
	public void increment1() {  // static method level synechorization
		synchronized (this) {		// make sure --> method --> multiple
			count++;
		}
	
	}
	
	 public static void decrement1() {
		 synchronized (Util.class) {
				count++;
			}
	}
	
}

class Ax extends Thread{
	int upTo;
	public Ax(int count,String name){
		super(name); // super -- constructor calling shud be the first statement
		this.upTo = count;
	}
	@Override
	public void run() {
		for(int i=0;i<upTo;i++) {
			Util.increment();
		}
		System.out.println(Thread.currentThread().getName() +" Completed..");
	}
}


class Bx extends Thread{
	int upTo;
	public Bx(int count,String name){
		super(name); // super -- constructor calling shud be the first statement
		this.upTo = count;
	}
	@Override
	public void run() {
		for(int i=0;i<upTo;i++) {
			Util.decrement();
		}
		System.out.println(Thread.currentThread().getName() +" Completed..");
	}
}