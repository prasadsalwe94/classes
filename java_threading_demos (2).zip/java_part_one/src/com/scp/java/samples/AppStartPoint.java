package com.scp.java.samples;

public class AppStartPoint {
		
	
	static public boolean m1(String param) {
		System.out.println("inside m1 :"+param);
		return false;
	}
	public static boolean m2(String param) {
		System.out.println("inside m2 : "+param);
		return true;
	}
	
	public static void main(String[] args) {
		if((m1("A") & m2("B")) & (m2("C") & m1("D"))) {
			System.out.println("inside if..");
		}else {
			System.out.println("inside else");
		}
	}

	
	public static void addition(int n1,int n2) {
		System.out.println("With 2 Params -->");
		int result = n1 + n2;
		System.out.println(result);
	}
	
	public static void addition(int n1,int n2,int n3) {
		System.out.println("With 3 Params -->");
		int result = n1 + n2 + n3;
		System.out.println(result);
	}
	
	public static void addition_v1(int num[]) {
		System.out.println("With Array Type param-->");
		int result = 0;
		for (int i : num) {
			result +=i;
		}
		System.out.println(result);
	}
	/**
	 * int ...num	
	 * 				varargs --- array
	 * 				param -- zero or more[MAX OF INTERGER]
	 * 				1 FUNCTION - MAXIMUM ONE VARARG TYPE
	 * 				VAR ARG -- SHUD BE LAST PARAM -- DYNAMIC PARAM
	 * 				least priority 
	 * 	method overloading 
	 * 			method check --
	 * 			no of params
	 * 			primitives -- implicit casting-
	 * 			integral-- int		
	 * 			decimal --double 
	 * 			autoboxing
	 * 			number --
	 * 			parent parent 
	 * 			object
	 * 			var..args-->
	 * 		
	 * 			addition(all primitive)-- all primitive
	 * 			addition(all wrappers)	--all wrappers
	 * 			addition(number)		numbers
	 * 			addition(object)		object
	 * 			addition(varargs)	-->
	 * 
	 * 
	 * 10 ---> int
	 * 			char ch = 'a';														char ..
	 * 			addition(ch) --> char - int -long-float-double -Charater--Object--varargs	
	 * 					10--> int long float double Integer NUmber Object Varargs
	 * 			
	 * @param num
	 */
	public static void addition(int ...num) {
		System.out.println("With Array Type param-->");
		int result = 0;
		for (int i : num) {
			result +=i;
		}
		System.out.println(result);
	}
}
