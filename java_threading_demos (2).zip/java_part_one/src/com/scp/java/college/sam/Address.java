package com.scp.java.college.sam;	// all small letters -- seperate it by dots.
								//package shud be first statement
/**
 * 
 * default			public Address()
 * 	or
 * no-arg			4:1 Address()
 * 
 * 
 * param			public Address(....)
 * 
 * 
 * @author Lenovo
 *	
 *
 *	1			-->1 	2 or 3 cannot be present --< public --> no
 *	2			2 or 3 --ahe --> 1 nasel
 *	3
 */

public class Address { // start with capital letter + camelcase
	private int adrId; // variable names--shud start with small letter + camelcase.
	private String city;
	private String state;
	private int pincode;
	private String lineNumber1; // no one can direct access these proeprties
								// except same class

	public Address() { // no-arg
	}
	
	//param --1
	public Address(int adrId, String city, String state, int pincode, String lineNumber1) {
		this.adrId = adrId;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.lineNumber1 = lineNumber1;
	}
	//param--2
	public Address( String city, int adrId,String state, int pincode, String lineNumber1) {
		this.adrId = adrId;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.lineNumber1 = lineNumber1;
	}
	
	public Address(Address adr) { //param with -- copy constructor
		
	}
	
	/**
	 * Constructors --> 3 types Constructors --> to initialize object properties 1.
	 * Default Constructor --> compiler 2. No-arg Constructor --> dev 3. Param
	 * Constructor -->dev --> copy constructor 1 -compiler --> if no constructor
	 * defined by dev 2 3
	 * 
	 * 11 --> not possible --> more than one default constructors in same class 12
	 * --> not possible 13 --> not possible 1 can not be with 2 or 3 -->
	 * 
	 * 2222 --> not possible --> 23 --> possible
	 * 
	 * 3333 --> possible --> overloading--> params diff --> change in num of param
	 * --> change in datatypes --> change in seq 23333 -->
	 * 
	 */

}
