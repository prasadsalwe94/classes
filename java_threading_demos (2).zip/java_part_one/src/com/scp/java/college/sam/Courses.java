package com.scp.java.college.sam;

public class Courses {

}
