package com.scp.java.college.sam;

public class Dept {
	private int deptId;
	private String deptCode;
	private String deptName;

	//no-arg
	public Dept() {
	}
	
	//param
	public Dept(int deptId, String deptCode, String deptName) {
		this.deptId = deptId;
		this.deptCode = deptCode;
		this.deptName = deptName;
	}
	
	//primitive and wrapper --> only java
	// nonprimitives 
	
	public static void main(String[] args) {
		int num = 10;	// primitive --> 4 bytes
						// num is variable --type of variable is
						// int
						//no structure-- not methods-- no classes
						//simple -- fast --> less and fix memory.
		
		Integer number1 = 20;		//20 INT--> AUTOBOXED TO INTEGER
		Integer number2 = new Integer(10);	
						//nonprimitive [wrapper] -- cannot say directly
						// memory less/more -->
						// specific structures
						// class --object --> methods/properties
						//conversion --> memory point of view--
						//heavy
		String name = "Java";  // LITERAL
						//nonprimitive-->not a wrapper
						// cannot say directly
						// follows specific structure
						// methods/varaibles -->
						//objects
						//created thru literal
		String lang = new String("Java"); // NEW THRU
						//NONPRIMITIVE
						// SYSTEM/JAVA DEFINED
						// LANG --> STRING -- JAVA DEFINED.
						// CANNOT --> FOLLOWS STRUCTURE--MORE METHODS/VARIABELS
						// MORE MEMORY REQUIRES
						// OBJECT--> cLASSE--> METHODS/PROPERTIES
	
		Dept dept1 = new Dept();//no-arg -- default values
					// dept --> nonprimitive
					//structure-->dev --> business--> college app
					//dept--> methods/variables
					//dept1 --> variable--> dept object
					// datatype --> Dept [id,code,name]
		Dept dept2 = new Dept(101,"IT","Information Tech.");
					//param -->
					// dept --> nonprimitive
					//structure-->dev --> business--> college app
					//dept--> methods/variables
					//dept1 --> variable--> dept object
					// datatype --> Dept [id,code,name]
		
	}
	
	/**
	 * 
	 * why to write a class ->
	 * 			
	 * 
	 * variables		-- diff bet
	 * 		instance
	 * 		static
	 * 		local
	 * methods			--diff bet
	 * 		static
	 * 		instance
	 * 
	 * constructors
	 * 		default
	 * 		no-arg
	 * 		param
	 * 
	 * accessmodifiers
	 * 		public
	 * 		protected
	 * 		private
	 * 		default
	 * 		
	 * 		static
	 * 		synechronized
	 * 		strictfp
	 * 		abstract
	 * 		final
	 * 		native
	 * 		volatile
	 * 		transite
	 * 
	 * 
	 * memory model-->
	 * 			class --> loading
	 * 					memory allocate
	 * 			classloaders
	 *	types of variables/methods ->
	 *			
	 *			structures-->
	 * 
	 */
	
}
