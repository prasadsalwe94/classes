package com.scp.java.demos;


public class OneMore {
	
}
/***
 * private -> only same class can access
 * default -> only same package classes/files can access
 * protected -> same package and other package che child classes only.
 * public  -> all packages/files/classes within same project.
 * 
 * 4:1 -->
 * 
 * 4 --> variables/methods/constructors -private public protected default
 * outerclasses --> default/public			-->abstract final
 * inner classes --> private public protected default
 *class
 *		variables  --> to hold values
 *		methods	   --> to write business logic --> set of instructions
 *		*blocks	   --> to write prequisites
 *		constructors --> to initialize instance/object properties
 *		
 *	variables/constructors/methods --> Access modifiers 4:1
 *			private/protected/public/default
 *  outer class --> default/public	--> abstract final
 *  			class---> private and protected -> inner class
 *
 *
 *	private
 *			variables/methods/constructors - can be accessed only
 *			inside same class -- not even in same file another classes
 *	public 
 *			public programming element can be accessed within same project
 *			inside any packages-- or any class.
 *
 *	protected
 *			same package anywhere -same file classes-- another file classes
 *					1 file can have n classes -->
 *							protected-- same file mein anywhere
 *					same package-- another file mein
 *							yes
 *
 *			another package -- madhe - only child classes can access
 *
 *	default  --> only within same pacakges files/classes
 *
 * Structure-->
 * 		class
 *		object = instance 
 *
 *	XXX.java	
 *		public class XXX{
 *
 *	   }		
 */
class Employee{
	
}