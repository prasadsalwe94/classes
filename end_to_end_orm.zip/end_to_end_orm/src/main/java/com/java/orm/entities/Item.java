package com.java.orm.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Item_INFO")
public class Item {
	
	@Id
	private int itemId;
	private String itemName;
	private double itemPrice;
	private String itemDesc;
	private int itemQty;
	
	@ManyToOne
	@JoinColumn(name = "ven_id")
	private Vendor vendor;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public int getItemQty() {
		return itemQty;
	}

	public void setItemQty(int itemQty) {
		this.itemQty = itemQty;
	}

	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	
	public Item(int itemId, String itemName, double itemPrice, String itemDesc, int itemQty) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemDesc = itemDesc;
		this.itemQty = itemQty;
	}

	public Item(int itemId, String itemName, double itemPrice, String itemDesc, int itemQty, Vendor vendor) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemDesc = itemDesc;
		this.itemQty = itemQty;
		this.vendor = vendor;
	}

	public Item() {
		super();
	}
	
	
}
