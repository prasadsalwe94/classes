package com.java.orm.util;

public interface AppConstants {
	
	String INVALID_PRODUCT = "Invalid Product Type Given";
	String PRODUCT_NOT_FOUND = "Product Not Found";
	String INVALID_PRODUCT_ID = "Invalid Product Id";
	String DUPLICATE_PRODUCT = "Duplicate Product";
	String INVALID_PRODUCT_FIELDS = "Invalid Product Fields";
	String EMPTY_PRODUCTS_LIST = "Product Not In Stock";
	String INVALID_VENDOR_ID = "Invalid Vendor Id";
}
