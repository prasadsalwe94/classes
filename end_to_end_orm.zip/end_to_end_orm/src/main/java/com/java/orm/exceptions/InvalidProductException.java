package com.java.orm.exceptions;

public class InvalidProductException extends Exception {
	
	public InvalidProductException(String message) {
		super(message);
	}
}
