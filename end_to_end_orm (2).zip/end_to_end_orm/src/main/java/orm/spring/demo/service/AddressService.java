package orm.spring.demo.service;

import java.util.List;

import com.java.orm.exceptions.InvalidEntity;

import orm.spring.demo.beans.Address;

public interface AddressService {
	public Address addNewAddress(Address adr) throws InvalidEntity;
	public Address modifyAddress(Address adr);
	public String removeAddress(int adrId);
	public Address getSingleAddress(int adrId);
	public List<Address> getAllAddresses();
}
