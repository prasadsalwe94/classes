package orm.spring.demo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import orm.spring.demo.beans.Roles;
import orm.spring.demo.service.RolesService;

@Service
public class RolesServiceImpl implements RolesService {

	public Roles addNewRoles(Roles role) {
		// TODO Auto-generated method stub
		return null;
	}

	public Roles modifyRoles(Roles role) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeRoles(int roleId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Roles getSingleRoles(int roleId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Roles> getAllRoles() {
		// TODO Auto-generated method stub
		return null;
	}

}
