package orm.spring.demo.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.java.orm.util.ORMUtil;

import orm.spring.demo.beans.Skills;
import orm.spring.demo.dao.SkillsServiceDao;
import orm.spring.demo.entities.SkillsE;
import orm.spring.demo.service.SkillsService;

@Repository
public class SkillsDaoImpl implements SkillsServiceDao{

	@Autowired
	private SessionFactory sessionfactory;
	
	public SkillsE addNewSkills(SkillsE skl) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.save(skl);
			return skl;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public SkillsE modifySkills(SkillsE skl) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.saveOrUpdate(skl);
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public String removeSkills(SkillsE skill) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.delete(skill);
			return "Record removed Successfully";
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public SkillsE getSingleSkills(int sklId) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.get(SkillsE.class,sklId);
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public List<SkillsE> getAllSkills() {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.createCriteria(SkillsE.class).list();
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}
	
}
