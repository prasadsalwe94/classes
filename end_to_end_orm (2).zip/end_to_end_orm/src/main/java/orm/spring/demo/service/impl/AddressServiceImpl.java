package orm.spring.demo.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.orm.exceptions.InvalidEntity;
import static com.java.orm.util.AppConstants.*; // i can access static fields directly..

import orm.spring.demo.beans.Address;
import orm.spring.demo.dao.AddressDao;
import orm.spring.demo.dao.impl.AddressDaoImpl;
import orm.spring.demo.entities.AddressE;
import orm.spring.demo.service.AddressService;

@Service("adr_service")
public class AddressServiceImpl implements AddressService {

	@Autowired
	public AddressDaoImpl adrDao;
	
	public Address addNewAddress(Address adr) throws InvalidEntity {
		if(adr==null) {
			throw new InvalidEntity(INVALID_ADDRESS);
		}else if (adr.getAdrId()<=0 || adr.getCity()!=null && adr.getCity().length()<=0 || adr.getPincode()<=99999 || adr
				.getPincode()>=1000000) {
			throw new InvalidEntity(INVALID_ADDRESS_FIELDS);
		}else if(null!=adrDao.getSingleAddressE(adr.getAdrId())) {
			throw new InvalidEntity("Duplicate Address Record");
		}else {
			//AddressE entity = beanToEntity(adr);
			//entity = adrDao.addNewAddressE(entity);
			//return entityToBean(entity);
			return entityToBean(adrDao.addNewAddressE(beanToEntity(adr)));
		}
	}

	private Address entityToBean(AddressE entity) {
		Address bean = new Address();
		if(entity!=null) {
			bean.setCity(entity.getCity());
			bean.setPincode(entity.getPincode());
			bean.setState(entity.getState());
			bean.setAdrId(entity.getAdrId());
		}
		
		return bean;
	}

	private AddressE beanToEntity(Address bean) {
		AddressE entity = new AddressE();
		if(bean!=null) {
			entity.setCity(bean.getCity());
			entity.setPincode(bean.getPincode());
			entity.setState(bean.getState());
			entity.setAdrId(bean.getAdrId());
		}
		
		return entity;
	}

	public Address modifyAddress(Address adr) {
		if(adr!=null && adr.getAdrId()>=1) {
			AddressE adrEntity = adrDao.getSingleAddressE(adr.getAdrId());
			if(adrEntity!=null) { // present asel tr
				adrEntity.setCity(adr.getCity());
				adrEntity.setPincode(adr.getPincode());
				adrEntity.setState(adr.getState());
				adrEntity = adrDao.modifyAddressE(adrEntity);
				return entityToBean(adrEntity);
			}
			
		}
		return null;
	}

	public String removeAddress(int adrId) {
		if(adrId>=1) {
			AddressE adrEntity = adrDao.getSingleAddressE(adrId);
			if(adrEntity!=null) {
				return adrDao.removeAddressE(adrEntity);
			}
		}
		return null;
	}

	public Address getSingleAddress(int adrId) {
		AddressE adrEntity = adrDao.getSingleAddressE(adrId);
		return entityToBean(adrEntity);
	}

	public List<Address> getAllAddresses() {
		List<AddressE> entities = adrDao.getAllAddressEes();
		return entityListToBeans(entities);
	}

	private List<Address> entityListToBeans(List<AddressE> entities) {
		List<Address> beans = new ArrayList<Address>();
		
		if(!entities.isEmpty()) {
			for (AddressE entity : entities) {
				beans.add(entityToBean(entity));
			}
		}
		
		return beans;
	}
	
}
