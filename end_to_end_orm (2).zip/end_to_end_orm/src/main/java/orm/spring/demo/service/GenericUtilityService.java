package orm.spring.demo.service;

public interface GenericUtilityService {
	//getRolesSpecificEmps
	//getAddressSepecificEmps
	//getMin/Max-->Salary
	//getJavaDevelopers--
}
