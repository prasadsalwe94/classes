package orm.spring.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EMP_INFO")
public class EmployeeE {
	@Id
	private int empId;
	private String empName;
	private String empGender;
	private double empSalary;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<AddressE> address; // 1emp -- m address
	
	@OneToOne(cascade = CascadeType.ALL)
	private RolesE roles;	// 1--1
	
	@ManyToMany
	private List<SkillsE> skills;	// M-M

	public EmployeeE(int empId, String empName, String empGender, double empSalary, List<AddressE> address,
			RolesE roles, List<SkillsE> skills) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empGender = empGender;
		this.empSalary = empSalary;
		this.address = address;
		this.roles = roles;
		this.skills = skills;
	}

	public EmployeeE(int empId, String empName, String empGender, double empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empGender = empGender;
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "EmployeeE [empId=" + empId + ", empName=" + empName + ", empGender=" + empGender + ", empSalary="
				+ empSalary + ", address=" + address + ", roles=" + roles + ", skills=" + skills + "]";
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public List<AddressE> getAddress() {
		return address;
	}

	public void setAddress(List<AddressE> address) {
		this.address = address;
	}

	public RolesE getRoles() {
		return roles;
	}

	public void setRoles(RolesE roles) {
		this.roles = roles;
	}

	public List<SkillsE> getSkills() {
		return skills;
	}

	public void setSkills(List<SkillsE> skills) {
		this.skills = skills;
	}
	
	
	
	
	
	
}
