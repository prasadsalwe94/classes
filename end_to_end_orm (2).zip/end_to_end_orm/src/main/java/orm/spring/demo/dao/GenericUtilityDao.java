package orm.spring.demo.dao;

public interface GenericUtilityDao {
	//getRolesSpecificEmps
	//getAddressSepecificEmps
	//getMin/Max-->Salary
	//getJavaDevelopers--
}
