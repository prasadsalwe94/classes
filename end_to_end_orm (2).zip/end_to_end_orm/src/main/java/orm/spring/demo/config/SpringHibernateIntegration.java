package orm.spring.demo.config;

import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

@Configuration		//Configuration --> class level annotation to create bean --> 
@PropertySource("classpath:database.properties")
@ComponentScan(basePackages  = "orm.spring.demo.*") // scan all steretotypes --> comps[generic]/controller[mvc]/service[business]/repo[db]
public class SpringHibernateIntegration {

	@Autowired				// search --enviroment type cha bean -> inside container--> object inject
	private Environment enviroment;
	
	
	@Bean		//place datasource instance --> spring container --> [specialized area]
	public BasicDataSource basicDataSource() {
		
		BasicDataSource datasource = new BasicDataSource();
		datasource.setUrl(enviroment.getProperty("hibernate.connection.url"));
		datasource.setDriverClassName(enviroment.getProperty("hibernate.connection.driver_class"));
		datasource.setUsername(enviroment.getProperty("hibernate.connection.username"));
		datasource.setPassword(enviroment.getProperty("hibernate.connection.password"));
		
		return datasource;
	}
	
	
	@Bean("sfactory")
	public LocalSessionFactoryBean localSessionFactory() {
		LocalSessionFactoryBean lbean = new LocalSessionFactoryBean();
		lbean.setDataSource(basicDataSource());		// database configuration
		lbean.setHibernateProperties(hibernateProps()); // hibernate configuration
		lbean.setPackagesToScan("orm.spring.demo.entities"); // scan entity classes and create database tables.
		return lbean;
	}


	private Properties hibernateProps() {
		Properties props = new Properties();
		props.put(org.hibernate.cfg.Environment.HBM2DDL_AUTO, enviroment.getProperty("hibernate.hbm2ddl.auto"));//inline import
		props.put(org.hibernate.cfg.Environment.SHOW_SQL, true);
		props.put(org.hibernate.cfg.Environment.DIALECT,enviroment.getProperty("hibernate.dialect"));
		return props;
	}
	
/*	
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringHibernateIntegration.class);
		//System.out.println(context.getBean("sfactory").hashCode());
		SessionFactory sessionFactory = (SessionFactory) context.getBean("sfactory");
		Session session = sessionFactory.openSession();
		System.out.println(session.hashCode());
	}
*/
}

/**
	normal import --*
	static import --**
	inline import -->***

*/