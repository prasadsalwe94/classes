package orm.spring.demo.dao;

import java.util.List;

import orm.spring.demo.entities.SkillsE;

public interface SkillsServiceDao {
	public SkillsE addNewSkills(SkillsE skl);
	public SkillsE modifySkills(SkillsE skl);
	public String removeSkills(SkillsE skl);
	public SkillsE getSingleSkills(int sklId);
	public List<SkillsE> getAllSkills();
}
