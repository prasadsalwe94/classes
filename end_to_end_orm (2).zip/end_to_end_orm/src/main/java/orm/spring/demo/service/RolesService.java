package orm.spring.demo.service;

import java.util.List;

import orm.spring.demo.beans.Roles;

public interface RolesService {
	public Roles addNewRoles(Roles role);
	public Roles modifyRoles(Roles role);
	public String removeRoles(int roleId);
	public Roles getSingleRoles(int roleId);
	public List<Roles> getAllRoles();
}
