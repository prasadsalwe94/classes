package orm.spring.demo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import orm.spring.demo.beans.Employee;
import orm.spring.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	public Employee addNewEmployee(Employee emp) {
		// dont wry about --> this --> atleast try this one too..
		
		//emp.getAddresss --> List-AddressE
		//emp.getSkills  -->  List-Skills
		//emp.getRole    --> Role
		
		//empE.set(adrList) empE.set(skilE) -empE.set(roleE)
		//empdao.adr(empE)	-->
		return null;
	}

	public Employee modifyEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee getSingleEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
