package orm.spring.demo.service;

import java.util.List;

import orm.spring.demo.beans.Skills;

public interface SkillsService {
	public Skills addNewSkills(Skills skl);
	public Skills modifySkills(Skills skl);
	public String removeSkills(int sklId);
	public Skills getSingleSkills(int sklId);
	public List<Skills> getAllSkills();
}
