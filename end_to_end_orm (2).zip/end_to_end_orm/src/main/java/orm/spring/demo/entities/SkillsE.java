package orm.spring.demo.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SKILL_INFO")
public class SkillsE {
	@Id
	private String skillCode;	// can string be a primary key --> YES
	private String skillName;
	
	public SkillsE(String skillCode, String skillName) {
		super();
		this.skillCode = skillCode;
		this.skillName = skillName;
	}
	public SkillsE() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getSkillCode() {
		return skillCode;
	}
	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
	
}
