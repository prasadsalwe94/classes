package orm.spring.demo.service.impl;

public class GenericUtilityServiceImpl {
	//getRolesSpecificEmps
	//getAddressSepecificEmps
	//getMin/Max-->Salary
	//getJavaDevelopers--
}
