package orm.spring.demo.beans;

public class Skills {
	private String skillCode;	// can string be a primary key --> YES
	private String skillName;
	
	public Skills(String skillCode, String skillName) {
		super();
		this.skillCode = skillCode;
		this.skillName = skillName;
	}
	public Skills() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getSkillCode() {
		return skillCode;
	}
	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
	
}
