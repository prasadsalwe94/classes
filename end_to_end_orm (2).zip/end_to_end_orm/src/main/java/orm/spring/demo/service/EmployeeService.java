package orm.spring.demo.service;

import java.util.List;

import orm.spring.demo.beans.Employee;

public interface EmployeeService {
	
	public Employee addNewEmployee(Employee emp);
	public Employee modifyEmployee(Employee emp);
	public String removeEmployee(int empId);
	public Employee getSingleEmployee(int empId);
	public List<Employee> getAllEmployees();
	
}
