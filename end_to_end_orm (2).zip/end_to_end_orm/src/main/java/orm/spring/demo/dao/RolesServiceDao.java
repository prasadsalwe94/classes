package orm.spring.demo.dao;

import java.util.List;

import orm.spring.demo.entities.RolesE;


public interface RolesServiceDao {
	public RolesE addNewRoles(RolesE role);
	public RolesE modifyRoles(RolesE role);
	public String removeRoles(RolesE role);
	public RolesE getSingleRoles(int roleId);
	public List<RolesE> getAllRoles();
}
