package orm.spring.demo.dao;

import java.util.List;

import orm.spring.demo.entities.EmployeeE;

public interface EmployeeDao {
	
	public EmployeeE addNewEmployeeE(EmployeeE emp);
	public EmployeeE modifyEmployee(EmployeeE emp);
	public String removeEmployee(EmployeeE emp);
	public EmployeeE getSingleEmployee(int empId);
	public List<EmployeeE> getAllEmployees();
	
}
