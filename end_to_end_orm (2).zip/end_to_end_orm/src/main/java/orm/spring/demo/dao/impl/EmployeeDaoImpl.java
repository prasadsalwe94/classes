package orm.spring.demo.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.java.orm.util.ORMUtil;

import orm.spring.demo.dao.EmployeeDao;
import orm.spring.demo.entities.EmployeeE;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{

	@Autowired
	private SessionFactory sessionfactory;
	
	public EmployeeE addNewEmployeeE(EmployeeE emp) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.save(emp);
			return emp;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	
	}

	public EmployeeE modifyEmployee(EmployeeE emp) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.saveOrUpdate(emp);
			return emp;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public String removeEmployee(EmployeeE emp) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.delete(emp);
			return "Record Removed Successfully.";
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public EmployeeE getSingleEmployee(int empId) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.get(EmployeeE.class, empId);
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public List<EmployeeE> getAllEmployees() {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.createCriteria(EmployeeE.class).list();
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}
	
}
