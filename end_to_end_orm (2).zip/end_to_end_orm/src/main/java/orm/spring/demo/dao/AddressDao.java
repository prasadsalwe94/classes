package orm.spring.demo.dao;

import java.util.List;

import orm.spring.demo.entities.AddressE;


public interface AddressDao {
	public AddressE addNewAddressE(AddressE adr);
	public AddressE modifyAddressE(AddressE adr);
	public String removeAddressE(AddressE adr);
	public AddressE getSingleAddressE(int adrId);
	public List<AddressE> getAllAddressEes();
}
