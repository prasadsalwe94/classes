package orm.spring.demo.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.java.orm.util.ORMUtil;

import orm.spring.demo.beans.Roles;
import orm.spring.demo.dao.RolesServiceDao;
import orm.spring.demo.entities.RolesE;
import orm.spring.demo.service.RolesService;

@Repository
public class RolesDaoImpl implements RolesServiceDao {

	@Autowired
	private SessionFactory sessionfactory;
	
	public RolesE addNewRoles(RolesE role) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.save(role);
			return role;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public RolesE modifyRoles(RolesE role) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.saveOrUpdate(role);
			return role;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public String removeRoles(RolesE role) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.delete(role);
			return "Record Removed Successfully";
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public RolesE getSingleRoles(int roleId) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.get(RolesE.class,roleId);
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public List<RolesE> getAllRoles() {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.createCriteria(RolesE.class).list();
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}
	
}
