package orm.spring.demo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import orm.spring.demo.beans.Skills;
import orm.spring.demo.service.SkillsService;

@Service
public class SkillsServiceImpl implements SkillsService{

	public Skills addNewSkills(Skills skl) {
		// TODO Auto-generated method stub
		return null;
	}

	public Skills modifySkills(Skills skl) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeSkills(int sklId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Skills getSingleSkills(int sklId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Skills> getAllSkills() {
		// TODO Auto-generated method stub
		return null;
	}

}
