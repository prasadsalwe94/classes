package orm.spring.demo.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.java.orm.util.AppConstants;
import com.java.orm.util.ORMUtil;

import orm.spring.demo.dao.AddressDao;
import orm.spring.demo.entities.AddressE;

@Repository
public class AddressDaoImpl implements AddressDao {

	@Autowired
	public SessionFactory sessionfactory;
	
	
	
	public AddressE addNewAddressE(AddressE adr) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.save(adr);
			return adr;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public AddressE modifyAddressE(AddressE adr) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.saveOrUpdate(adr);
			return adr;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public String removeAddressE(AddressE adr) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.delete(adr);
			return AppConstants.RECORD_REMOVED_SUCCESS;
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public AddressE getSingleAddressE(int adrId) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.get(AddressE.class,adrId);
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public List<AddressE> getAllAddressEes() {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			return session.createCriteria(AddressE.class).list();
		}catch (Exception e) {
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}
	
}
