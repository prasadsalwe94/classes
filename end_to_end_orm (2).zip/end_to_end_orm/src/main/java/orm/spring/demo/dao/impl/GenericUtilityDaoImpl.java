package orm.spring.demo.dao.impl;

public class GenericUtilityDaoImpl {
	//getRolesSpecificEmps
	//getAddressSepecificEmps
	//getMin/Max-->Salary
	//getJavaDevelopers--
}
