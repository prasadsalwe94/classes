package com.java.orm.config;

import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

@Configuration		//SpringOrmConfig --inside container
@PropertySource("classpath:database.properties")
@ComponentScan(basePackages = "com.java.orm.*")//service--repository
public class SpringOrmConfig {
	
	@Autowired		
	Environment env;
	
	@Bean("ds")		//method level annotations-->to create bean
	public BasicDataSource dataSourceConfig() {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUrl(env.getProperty("hibernate.connection.url"));
		dataSource.setUsername(env.getProperty("hibernate.connection.username"));
		dataSource.setPassword(env.getProperty("hibernate.connection.password"));
		dataSource.setDriverClassName(env.getProperty("hibernate.connection.driver_class"));
		return dataSource;
		
	}
	
	@Bean("localSFactory")
	public LocalSessionFactoryBean localSessionFactory() {
		LocalSessionFactoryBean lbean = new LocalSessionFactoryBean();
		//lbean.setAnnotatedClasses(Product.class);
		lbean.setPackagesToScan("com.java.orm.entities");
		lbean.setHibernateProperties(configORMProperties());
		lbean.setDataSource(dataSourceConfig());
		return lbean;
	}
	
	
	public Properties configORMProperties() {
		Properties props = new Properties();
		props.put(org.hibernate.cfg.Environment.DIALECT, env.getProperty("hibernate.dialect"));
		props.put(org.hibernate.cfg.Environment.SHOW_SQL, true);
		props.put(org.hibernate.cfg.Environment.HBM2DDL_AUTO, env.getProperty("hibernate.hbm2ddl.auto"));
		return props;
	}
}
