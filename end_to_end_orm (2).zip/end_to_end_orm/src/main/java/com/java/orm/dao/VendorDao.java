package com.java.orm.dao;

import com.java.orm.entities.Vendor;

public interface VendorDao {

	public Vendor getVendor(int venId);
}
