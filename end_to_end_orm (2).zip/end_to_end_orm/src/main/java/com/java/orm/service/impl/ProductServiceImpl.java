package com.java.orm.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.orm.beans.Product;
import com.java.orm.dao.impl.ProductDaoImpl;
import com.java.orm.dao.impl.VendorDaoImpl;
import com.java.orm.entities.Item;
import com.java.orm.entities.Vendor;
import com.java.orm.exceptions.InvalidProductException;
import com.java.orm.service.ProductService;
import com.java.orm.util.AppConstants;

@Service("pservice")	//ProductServiceImpl --> bean will be created inside container
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	public ProductDaoImpl prodDao;
	
	@Autowired
	public VendorDaoImpl vendorDao;
	
	public Product addProduct(Product prod) throws InvalidProductException {
		if(prod==null) {
			throw new InvalidProductException(AppConstants.INVALID_PRODUCT);
		}else if(getSingleProduct(prod.getProdId())!=null) {
			throw new InvalidProductException(AppConstants.DUPLICATE_PRODUCT);
		}else if(prod.getProdPrice()<=0 || prod.getProdQty()<=0) {
			throw new InvalidProductException(AppConstants.INVALID_PRODUCT_FIELDS);
		}else {
			//prod --> prodinfo + vendorInfo
			
			Item item = new Item(prod.getProdId(),prod.getProdName(),prod.getProdPrice(),prod.getProdDesc(),prod.getProdQty());
			
			Vendor vendor = vendorDao.getVendor(prod.getVendorId());
			
			if(vendor==null) {
				vendor = new Vendor(prod.getVendorId(),prod.getVendorName());
				
				List<Item> items = new ArrayList<Item>();
				items.add(item);
				
				//vendor is aware about --> items  // bidirectional
				vendor.setItems(items);
				
				//item is aware about --> vendor ---> bidirectional
				item.setVendor(vendor);
			}else {
				item.setVendor(vendor);
			}
			
			 item = prodDao.insertItem(item);
			 return new Product(item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemDesc(),item.getItemQty());
		}
	}

	public List<Product> getProducts() {
		List<Item> items = prodDao.getItems();
		List<Product> products = new ArrayList<Product>();
		for (Item item : items) {
			products.add(new Product(item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemDesc(),item.getItemQty()));
		}
		return products;
	}

	public boolean deleteProduct(int prodId) {
		Item item = prodDao.getSingleProduct(prodId);
		if(item!=null) {
			return prodDao.removeItem(item);
		}
		return false;
	}

	public Product updateProduct(int prodId, Product prod) {
		Item item = prodDao.getSingleProduct(prodId);
		if(item!=null) {
			item.setItemDesc(prod.getProdDesc());
			item.setItemName(prod.getProdName());
			item.setItemPrice(prod.getProdPrice());
			item.setItemQty(prod.getProdQty());
			item =  prodDao.updateProduct(item);
			return new Product(item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemDesc(),item.getItemQty());
		}
		return null;
	}

	public Product getSingleProduct(int prodId) {
		Item item = prodDao.getSingleProduct(prodId);
		if(item!=null) {
			return new Product(item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemDesc(),item.getItemQty());
		}
		return null;
	}

	public List<Product> fetchVendorSpecificProducts(String vendorName) {
		List<Item> items = prodDao.fetchVendorSpecificProducts(vendorName);
		List<Product> products = new ArrayList<Product>();
		for (Item item : items) {
			products.add(new Product(item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemDesc(),item.getItemQty()));
		}
		return products;
	}

	public Product getMaxPriceProducts() {
		Item item = prodDao.getMaxPriceProducts();
		if(item!=null) {
			return new Product(item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemDesc(),item.getItemQty());
		}
		return null;
	}

	public List<Product> getProductsWithinPriceRange(double min, double max) {
		List<Item> items = prodDao.getProductsWithinPriceRange(min, max);
		List<Product> products = new ArrayList<Product>();
		for (Item item : items) {
			products.add(new Product(item.getItemId(),item.getItemName(),item.getItemPrice(),item.getItemDesc(),item.getItemQty()));
		}
		return products;
	}

	public String deleteListProducts(List<Integer> values) {
		for (Integer itemId : values) {
			Item item = prodDao.getSingleProduct(itemId);
			if(item!=null) {
				prodDao.removeItem(item);
			}
		}
		return "Products Removed";
	}

	public String addProductsInBulk(List<Product> products) {
		for (Product prod : products) {
			Item item = new Item(prod.getProdId(),prod.getProdName(),prod.getProdPrice(),prod.getProdDesc(),prod.getProdQty());
			Item dbItem = prodDao.getSingleProduct(item.getItemId());
			if(dbItem!=null)
				prodDao.insertItem(item);
		}
		return "Products Added";
	}

}
