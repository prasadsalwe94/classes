package com.java.orm.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.java.orm.dao.ProductDao;
import com.java.orm.entities.Item;
import com.java.orm.entities.Vendor;
import com.java.orm.util.ORMUtil;

@Repository  // will create an instance of-->ProductDaoimpl-->containermadhe
public class ProductDaoImpl implements ProductDao{

	@Autowired			//search karel inside container madhe--. sesessfactory type 
	public SessionFactory sessionfactory;		/// configurations
	
	public Item insertItem(Item item) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.save(item);
			return item;
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public List<Item> getItems() {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			return session.createCriteria(Item.class).list();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public boolean removeItem(Item item) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.delete(item);
			return true;
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return false;
	}

	public Item updateProduct(Item item) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			session.update(item);
			return item;
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public Item getSingleProduct(int itemId) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			return session.get(Item.class,itemId);
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public List<Item> fetchVendorSpecificProducts(String vname) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			
			//select * from vendor
			Criteria cr = session.createCriteria(Vendor.class);
			//where vendorName = "Flipkart"
			cr.add(Restrictions.eq("vendorName", vname));
			//all vendors with name --> flipkart --> 0 - n
			List<Vendor> vendors = cr.list();
			if(!vendors.isEmpty()) {
				
				if(vendors.size()==1) {
					return vendors.get(0).getItems();
				}else {
					List<Item> items = new ArrayList<Item>();
					
					for (Vendor vendor : vendors) {
						items.addAll(vendor.getItems());
					}
					return items;
				}
					
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public Item getMaxPriceProducts() {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			Criteria crit = session.createCriteria(Item.class);
			crit.setProjection(Projections.max("itemPrice"));
			return (Item) crit.uniqueResult();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

	public List<Item> getProductsWithinPriceRange(double min, double max) {
		Session session = null;
		Transaction tr = null;
		try {
			session = sessionfactory.openSession();
			tr = session.beginTransaction();
			Criteria crit = session.createCriteria(Item.class);
			crit.add(Restrictions.in("itemPrice", 100.0,200.0));
			return crit.list();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			ORMUtil.cleanUp(session, tr);
		}
		return null;
	}

}
