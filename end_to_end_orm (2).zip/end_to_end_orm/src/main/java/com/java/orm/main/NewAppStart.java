package com.java.orm.main;

import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.java.orm.exceptions.InvalidEntity;

import orm.spring.demo.beans.Address;
import orm.spring.demo.config.SpringHibernateIntegration;
import orm.spring.demo.dao.impl.AddressDaoImpl;
import orm.spring.demo.service.AddressService;
import orm.spring.demo.service.impl.AddressServiceImpl;

public class NewAppStart {
	public static void main(String[] args) throws InvalidEntity {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringHibernateIntegration.class);
		AddressServiceImpl service = (AddressServiceImpl) context.getBean("adr_service");
		//AddressDaoImpl dao = service.adrDao;
		//SessionFactory sfactory = dao.sessionfactory;
		
		//System.out.println("Service --> "+service);
		//System.out.println("Dao --> " +dao);
		//System.out.println("Sessionfactory -->"+sfactory);
		
		
		
		System.out.println(service.getAllAddresses());
		
		System.exit(0);
		
		Address address1 = new Address(106,"Pune1","MH1", 722122);
		Address address2 = new Address(102,"Pune2","MH2", 622122);
		Address address3 = new Address(103,"Pune3","MH3", 522122);
		Address address4 = new Address(104,"Pune4","MH4", 422122);
		Address address5 = new Address(105,"Pune5","MH5", 322122);
		
		service.addNewAddress(address1);
		service.addNewAddress(address2);
		service.addNewAddress(address3);
		service.addNewAddress(address4);
		service.addNewAddress(address5);
		
		/**
		 * address --> completed..
		 *   similar way ne --.
		 *   	skills		--> mandatory
		 *      employee	--> mandatory* -->
		 *      role --.	--> mandatory
		 * 
		 * attaprynt --> to entire code-->write karta yayla pahije
		 * proj structure clear pahije-->
		 * 
		 */
		
	}
}
