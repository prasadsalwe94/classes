package com.java.orm.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.java.orm.config.SpringOrmConfig;
import com.java.orm.service.impl.ProductServiceImpl;

public class ApplicationStart {
	
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringOrmConfig.class);
		ProductServiceImpl serviceimpl = (ProductServiceImpl) context.getBean("pservice");
		System.out.println("ServiceImpl -->"+serviceimpl.hashCode());
		System.out.println("PRODUCTDAOIMPL -->"+serviceimpl.prodDao.hashCode());
		System.out.println("SESSIONFACTORY -->"+serviceimpl.prodDao.sessionfactory.hashCode());
		
		System.out.println("VEndorDaoImpl -->"+serviceimpl.vendorDao.hashCode());
		System.out.println("Ven ->SESSIONFACTORY -->"+serviceimpl.vendorDao.sessionFactory.hashCode());
		
		
	}
}
