package com.java.orm.service;

import java.util.List;

import com.java.orm.beans.Product;
import com.java.orm.exceptions.InvalidProductException;

public interface ProductService {
	public Product addProduct(Product prod) throws InvalidProductException;
	public List<Product> getProducts(); // all
	public boolean deleteProduct(int prodId);
	public Product updateProduct(int prodId,Product prod);
	public Product getSingleProduct(int prodId);//single
	public List<Product> fetchVendorSpecificProducts(String vendorName);
	public Product getMaxPriceProducts();
	public List<Product> getProductsWithinPriceRange(double min,double max);
	public String deleteListProducts(List<Integer> values);
	public String addProductsInBulk(List<Product> products);
}
