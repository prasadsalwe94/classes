package com.java.orm.util;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ORMUtil {
		
	
	public static void cleanUp(Session session,Transaction tr) {
		if(session!=null) {
			if(tr!=null) {
				session.flush();
				tr.commit();
			}
			session.close();
		}
	}
	
}
