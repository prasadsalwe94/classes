package com.java.orm.dao;

import java.util.List;

import com.java.orm.entities.Item;

public interface ProductDao {
	public Item insertItem(Item item);
	public List<Item> getItems(); 
	public boolean removeItem(Item item);
	public Item updateProduct(Item item);
	public Item getSingleProduct(int itemId);
	public List<Item> fetchVendorSpecificProducts(String vendorName);
	public Item getMaxPriceProducts();
	public List<Item> getProductsWithinPriceRange(double min,double max);
}	
