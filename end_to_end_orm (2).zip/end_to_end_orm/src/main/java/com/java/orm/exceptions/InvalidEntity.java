package com.java.orm.exceptions;

public class InvalidEntity extends Exception{
	
	public InvalidEntity(String message){
		super(message);
	}
}
