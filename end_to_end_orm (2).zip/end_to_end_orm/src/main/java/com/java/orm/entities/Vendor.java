package com.java.orm.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "vendor_info")
public class Vendor {

	@Id
	private int vendorId;
	private String vendorName;
	
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "vendor")
	private List<Item> items;

	public Vendor() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Vendor(int vendorId, String vendorName) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
	}



	public Vendor(int vendorId, String vendorName, List<Item> items) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.items = items;
	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	
	
	
}
