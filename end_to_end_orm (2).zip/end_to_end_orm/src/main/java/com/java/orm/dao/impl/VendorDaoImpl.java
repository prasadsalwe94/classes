package com.java.orm.dao.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.java.orm.dao.VendorDao;
import com.java.orm.entities.Vendor;

@Repository
public class VendorDaoImpl implements VendorDao{

	@Autowired
	public SessionFactory sessionFactory;
	
	public Vendor getVendor(int venId) {
		return null;
	}
	
}
