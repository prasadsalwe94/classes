package com.demo.clonning;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeUnit;

public class TestClonning {
		public static void main(String[] args) throws CloneNotSupportedException, InterruptedException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException {
			
			NEmployee object = (NEmployee) Class.forName("com.demo.clonning.NEmployee").newInstance();
			System.out.println(object);
			
			System.exit(0);
NEmployee n1 = new NEmployee();
System.out.println(n1); // 10

Field [] fields = NEmployee.class.getDeclaredFields();
for (Field field : fields) {
	field.setAccessible(true); // bypass kel ahe-- loopwhole
	field.set(n1,25);
}
System.out.println(n1);


			System.exit(0);
			
			Constructor contructors [] = NEmployee.class.getDeclaredConstructors();
			for (Constructor constructor : contructors) {
				NEmployee e1 = (NEmployee) constructor.newInstance(); // reflection mechanism
				System.out.println(e1);
			}
			
			System.exit(0);
			
			Employee e1 = new Employee(101, "Mr XXXX",new StringBuffer("SSE"), new Address(1111,"Pune"));
			Employee e2 = e1.clone();
			
			System.out.println(e1.hashCode());
			System.out.println(e2.hashCode());
			
			System.out.println(e1);
			System.out.println(e2);
			
			e1 = null;
			e2 = null;
			int num = 1;
			System.gc(); // this is just an trigger to gc activity --> bt not gc ---> call krtoy-- > municipal
			while(true) {
				System.out.println("Inside While"+num);
				if(num>=100)
					TimeUnit.SECONDS.sleep(1);
				
				num++;
			}
		
		}
}


class Address implements Cloneable{
	private int pincode;
	private String city;
	
	@Override
	protected Address clone() throws CloneNotSupportedException {
		return (Address)super.clone();
	}
	
	public Address(int pincode, String city) {
		super();
		this.pincode = pincode;
		this.city = city;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Address [pincode=" + pincode + ", city=" + city + "]";
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
}

class NEmployee {
	private int role = 10;
	public NEmployee() {
		System.out.println("Inside NEmployee-- NO Arg");
	}
	@Override
	public String toString() {
		return "NEmployee [role=" + role + "]";
	}
}
// jVM is already aware -- emp class is going to be clonned--> 
		// so whatever special functionalities at runtime --> in order to clone-->
		// jvm will be prepared for that--> 
class Employee implements Cloneable{
	private int empId;			
	private String empName;		
	private StringBuffer empDesignation;
	private Address empAddress;
	
	
	@Override
	protected void finalize() throws Throwable {
		//whatever code that u want ---> y can--> --->     whenver java performs gc collection activity-> just before 
				// this method will be called--> we never explicitly give calll--> we shud not give call-->
		System.out.println("Inside Finalize method...!");
	}
	
	@Override
	protected Employee clone() throws CloneNotSupportedException {
		Employee clonnedEmp =  (Employee) super.clone();		// Empclone
		
		Address clonnedAdr  = clonnedEmp.getEmpAddress().clone();	// Address
		clonnedEmp.setEmpAddress(clonnedAdr);
		
		StringBuffer newBuffer  = new StringBuffer(this.getEmpDesignation());
		clonnedEmp.setEmpDesignation(newBuffer);
		
		return clonnedEmp;
	}
	
	
	public Employee(int empId, String empName, StringBuffer empDesignation, Address empAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDesignation = empDesignation;
		this.empAddress = empAddress;
	}
	@Override
	public String toString() {
		return "\n [empId=" + empId + ", empName=" + empName + ", empDesignation=" + empDesignation
				+ ", empAddress=" + empAddress + "]";
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public StringBuffer getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(StringBuffer empDesignation) {
		this.empDesignation = empDesignation;
	}
	public Address getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(Address empAddress) {
		this.empAddress = empAddress;
	}
	public Employee() {
		super();
	}
	
	
	
	
}



/**
 * 
 * 
 * 		String 			vs 					StringBuffer					vs 			Stringbuilder
 * 		immutable							mutable										mutable
 * 		ThreadSafe [toggle btn]				ThreadSafe[Synechronized]					NOt ThreadSafe
 * 		1.0									1.0											1.0
 * 		comparable							-											-
 * 		-									reverse										reserve
 * 
 * Clonning --> 
 * 			creating another copy --
 * 					why to create copy -->
 * 							backup purpose
 * 							security
 * 
 * Creating an object--> is costly processs
 * 
 * Types of Clonning
 * 		Shallow -->
 * 					org --> in case original madhe change kel --> impact-- duplicate--> shallow clonning
 * 					dupl
 * 		Deep
 * 
 * 
 * class A:
 * 
 * class B(A):
 * 
 * class C(B):
 * 
 * class D(C):
 * 
 * 
 * class E(D):
 * 
 * E e1 = new E()		---> class loading	
 * 					A B C D E --> 5*3 --> 15 steps for class loading-- just to create single instance of E
 * 							scan static fields --> allocate memory on method area -- execute static blocks
 * 						---> Object Creation
 * 					A B C D E --> --> 5*3 --> 15 steps for class loading-- just to create single instance of E
 * 							Scan instance fields allocate memory --> execute Instance Blocks -- execute Constructor
 *  		e1--> 30
 *  
 * E e2 = new E(); --> 15
 * 
 * 
 *  E e1 = new E()
 *  E e2 = e1.clone()	--> single step --> perm --> too fast
 *  E e3 = e1.clone()	--> single step	--> perm --> too fast
 *  
 *  
 *  Serialization -->  is process of converting --> lang[JAVA] object into network supported/file supported format --->
 *  
 *                                  network supported --. to transfer over the network
 *                                  file supported --> to persist ->
 *                         
 *                         object --> data --> fields:values-->
 *                         
 *                         SERIALIZATION = PROCESS OF CONVERTING --> LANG OBJECT --. N/W OR FILE SUPPORTED FORMAT
 *  Deserialization 	---. PROCESS OF CONRTING N/W OR FILE SUPPORTED FORMAT INTO LANG OBJECT
 *  
 * 
 */
