package com.demo.clonning;

public class NestedTryCatchScenarios {

	
	public static int m1() {
		
		System.out.println("m1 Started...3");
		try {
			System.out.println("Inside try..4");
					try {	
						System.out.println("Inner try..5");
						int num [] = new int[2];
						System.out.println(num[2]);// ArrayIndexOutOfBound --> raise hoel--> search catch block which can handle AIOB
						System.out.println("inner try completed");
					}catch (ArithmeticException e) {
						System.out.println("ArithMaticException.!..");
					}finally {
						System.out.println("inside inner finally..6");
						
					}
			System.out.println("try completed..");
			return 1;
		}catch(NullPointerException e) {
			System.out.println("NUllpointer Exception");
			System.out.println("First Catch Block Completed..!");
			return 2;
		}catch(IndexOutOfBoundsException e) {
			System.out.println("Index Out of Bound..7");
			try {	
				System.out.println("Inner try..8");
				int num [] = new int[2];
				System.out.println(num[2]);// ArrayIndexOutOfBound --> raise hoel--> search catch block which can handle AIOB
				System.out.println("inner try completed");
			}catch (ArithmeticException e1) {
				System.out.println("ArithMaticException.!..");
			}finally {
				System.out.println("inside inner finally..9");
			}
			System.out.println("Second Catch Block Completed..");
			return 3;
		}finally {
			System.out.println("Finally block Executed...10");
			//return 4;
		}
		
		//System.out.println("M1 completed...!...");
		
	}
	
	public static void m2() {
		System.out.println("Inside m2...2");
		m1(); // AIOB
		System.out.println("M2 completed..");
	}
	
	public static void main(String[] args) {
		System.out.println("Inside main..1");
		m2();
		System.out.println("Main completed..");
	}
	
	

}
