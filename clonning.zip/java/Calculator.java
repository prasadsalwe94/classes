package com.demo.java;

public class Calculator implements CalculatorService {

	@Override
	public int addition(int num1, int num2) {
		int result = num1 + num2;
		System.out.println("Inside Addition :"+num1 + "+"  +num2  +" = " +result);
		return result;
	}

	@Override
	public int substraction(int num1, int num2) {
		int result = 0;
		if(num1<0 && num2<0) {
			result = num1 - num2;
		}else if(num1<0 || num2<0) {
			result = num1 + num2;
		}else {
			result = num1 - num2;
		}
		System.out.println("Inside Substraction :"+num1 + "-"  +num2  +" = " +result);
		return result;
	}

	@Override
	public int multiplication(int num1, int num2) {
		int result = num1 * num2;
		System.out.println("Inside multiplication :"+num1 + "*"  +num2  +" = " +result);
		return result;
	}

	@Override
	public int division(int num1, int num2) throws InvalidSecondParam {
		if(num2==0) {
			throw new InvalidSecondParam("Second Number cannot be zero in division operation");
		}
		int result = num1 / num2;
		System.out.println("Inside Division :"+num1 + "/"  +num2  +" = " +result);
		return result;
	}

	@Override
	public int doubles(int num1) {
		int result = num1 * 2;
		System.out.println("Inside Doubles :"+num1 + "(*2)"   +" = " +result);
		return result;
	}
	
	
}


class InvalidSecondParam extends Exception{
	public InvalidSecondParam(String msg) {
		super(msg);
	}
}

class NonNegativeRequired extends Exception{
	public NonNegativeRequired(String msg) {
		super(msg);
	}
}

interface CalculatorService {
	public int addition(int num1,int num2);
	public int substraction(int num1,int num2);
	public int multiplication(int num1,int num2);
	public int division(int num1,int num2) throws InvalidSecondParam;
	public int doubles(int num1);
}