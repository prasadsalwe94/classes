package com.demo.java.poly;

public class StartSample {
	public static void main(String[] args) {
		FruitJuiceMaker juiceMaker1 = new Hotel();
		//FruitJuiceMaker juiceMaker2 = new Hotel();
		
		Fruit fr = juiceMaker1.prepareJuice("O");	//Fruit fr ??
		if(fr instanceof Apple) {
			Apple ap = (Apple)fr;
			System.out.println("This is apple Juice..!"+ap);
		}else if(fr instanceof Orange) {
			Orange or = (Orange)fr;
			System.out.println("This orange Juice..!"+or);
		}else if(fr instanceof Mangoes) {
			Mangoes mg = (Mangoes) fr;
			System.out.println("This is Mangoes Juice"+mg);
		}
				
		
		
		
	}
}

class Fruit {
	private String content1;

	public Fruit(String content1) {
		super();
		this.content1 = content1;
	}

	public Fruit() {
		super();
	}

	@Override
	public String toString() {
		return "Fruit [content1=" + content1 + "]";
	}

	
	
	
}

class Apple extends Fruit{
	private String appleContent;
	public Apple(String content1) {
		super(content1);
	}

	

	@Override
	public String toString() {
		return "Apple [appleContent=" + appleContent + "]"+super.toString();
	}



	public Apple() {
		super();
	}

	public Apple(String content1, String appleContent) {
		super(content1);
		this.appleContent = appleContent;
	}
	
	
	
}

class Orange extends Fruit{
	private String orangeContent;
	public Orange(String content1) {
		super(content1);
	}

	
	public Orange() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Orange(String content1, String orangeContent) {
		super(content1);
		this.orangeContent = orangeContent;
	}


	@Override
	public String toString() {
		return "Orange [orangeContent=" + orangeContent + "]"+super.toString();
	}


	
}

class Mangoes extends Fruit{
	private String mangoesContent;
	public Mangoes(String content1) {
		super(content1);
	}

	
	@Override
	public String toString() {
		return "Mangoes [mangoesContent=" + mangoesContent + "]"+super.toString();
	}


	public Mangoes(String content1, String mangoesContent) {
		super(content1);
		this.mangoesContent = mangoesContent;
	}


	public Mangoes() {
		super();
		// TODO Auto-generated constructor stub
	}


	
}


abstract class FruitJuiceMaker{
	abstract public Fruit prepareJuice(String whichType);
}


class Hotel extends FruitJuiceMaker{
	
	public Hotel() {
		System.out.println("Hotel Called..");
	}
	
	@Override
	public Fruit prepareJuice(String whichType) {		// Fruit f1 = new Mangoes()
		if(whichType.equals("M")) {						// Fruit f2 = new Apple()
			return new Mangoes("90.0","MangoJuice");	// Fruit f3 = new Orange()
		}else if(whichType.equals("O")) {
			return new Orange("70.0","OrangeJuice");
		}else if(whichType.equals("A")) {
			return new Apple("120.0","AppleJuice");
		}
		System.out.println("Invalid Choice..!");
		return null;
	}
	
}

class Home extends FruitJuiceMaker{

	public Home() {
		System.out.println("Home called..");
	}
	
	@Override
	public Fruit prepareJuice(String whichType) {		// Fruit f1 = new Mangoes()
		if(whichType.equals("M")) {						// Fruit f2 = new Apple()
			return new Mangoes("30.0","MangoJuice");	// Fruit f3 = new Orange()
		}else if(whichType.equals("O")) {
			return new Orange("20.0","OrangeJuice");
		}else if(whichType.equals("A")) {
			return new Apple("50.0","AppleJuice");
		}
		System.out.println("Invalid Choice..!");
		return null;
	}
	
	public void relaxationRoom() {
		System.out.println("Inside Home -- relax");
	}
	
	public void entertainmaintent() {
		System.out.println("Inside home -- entertainment");
	}
	
	
}




class Mobile{
				// tightly encapsulation
	class Battery{
		
	}
}
/**

	datatypes
	oop  --> **
	looping
	assignments
	implicit/explict
	autoboxing unboxing
	env setup -->* 		JAVA_HOME --> 
	jdk/jre/jvm

*/