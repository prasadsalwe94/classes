package com.demo.java.poly;

public class StartApp {
	public static void main(String[] args) {
		Parent pc  = new Child();
		pc.m1();
		
		Child c1 = new Child();
		c1.m1();
		
		System.out.println("--- AA --");
		A a = new A();
		a.m1();
		System.out.println("--- BB --");
		B b = new B();
		b.m1();
		System.out.println("--- CC --");
		C c = new C();
		c.m1();
		
		
		System.out.println("--- AB --");
		
		A ab = new B();
		ab.m1();  // A and B --> konachi --> Runtime object-- B
		ab.am2();
		ab.am3();
		
		System.out.println("--- AC --");
		A ac = new C();
		ac.m1();
		
		System.out.println("--- BC --");
		B bc = new C();
		bc.m1(); // C chi --> 
		
		
	}
}


abstract class Parent{
	abstract public void m1();
	
}


class Child extends Parent {

	@Override
	public void m1() {
		System.out.println("Inside m1 --> Child class");
	}
	
}




class A{
	
	public void m1() {
		System.out.println("inside A ---> m1");
	}
	public void am2() {
		System.out.println("inside A ---> m2");
	}
	public void am3() {
		System.out.println("inside A ---> m3");
	}
	
	
}

class B extends A{
	public void m1() {
		System.out.println("inside B ---> m1");
	}
	public void bm2() {
		System.out.println("inside B ---> m2");
	}
	public void bm3() {
		System.out.println("inside B ---> m3");
	}
}

class C extends B{
	public void m1() {
		System.out.println("inside C---> m1");
	}
	public void cm2() {
		System.out.println("inside B ---> m2");
	}
	public void cm3() {
		System.out.println("inside B ---> m3");
	}
}