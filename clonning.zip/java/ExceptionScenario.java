package com.demo.java;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class ExceptionScenario {
	// default exception handler --> if exception generated in a code any point of time->
	// that exception will be propogated to the immediate caller -> and so on immediate caller 
	//till that that exception is not handled --> if this propogation happens till main method call--
	// from --> tithe jo code written to handle that exception -- > default exception handler..
	
	
	
	public static void main(String[] args) {
		System.out.println("Main started....");
		try {
			m1();
		} catch (InvalidName e) {
			System.out.println(e.getMessage());
		} // load it on thread stack - outof bound
		System.out.println("Calling to m5");
		m5();
		System.out.println("Main method completed..");
	}

	private static void m1() throws InvalidName {
		System.out.println("inside m1 method");
		m2();
		System.out.println("m1 method execution completed..");
	}
	
	private static void m2() throws InvalidName {
		System.out.println("inside m2 method");
		m3();
		System.out.println("m2 method execution completed..");
	}
	
	private static void m3() throws InvalidName {
		System.out.println("inside m3 method");
		try {
			m4();//outofbound
		}catch (NullPointerException e) {
		}catch (StringIndexOutOfBoundsException e) {
		}
		
		System.out.println("m3 method execution completed..");
	}
	
	private static void m4() throws InvalidName {
		System.out.println("inside m4 method");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Name : ");
		String name = sc.next();
		try {
			System.out.println("4th char is ->" +name.charAt(3)); //outofbound  --abnormal condition
		}catch(ArithmeticException e) {
			throw new InvalidName("Atleast 4 char name required..!");
		}
		System.out.println("m4 method execution completed..");
	}
	
	private static void m5() {
		System.out.println("inside m5 method");
		System.out.println("m5 method execution completed..");
	}

}

class InvalidName extends Exception{
	public InvalidName(String msg) {
		super(msg);
	}
}
/**
 * 
 * Ideally used with user defined exceptions...
 * 
 */
