package com.demo.java;

import java.io.File;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TestCalculator2 {

	/**
	 * InputMismatchException,NoSuchElementException --> Unchecked --> compiler is not aware -- these events directly occures at runtime
	 * 								unchecked --> always childs of RuntimeException
	 * 								
	 * 
	 * InterruptedException, --> Checked	--> compiler is aware about these conditions/events
	 * 							checked exception are a child of Exception
	 * 
	 * 
	 * 
	 * 			let it checked / unchecked exceptions --. 
	 * 						always occurs at runtime..
	 * 
	 * 
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		

		
		
		int [] number1 = new int[5];
		int index = 0;
		
		
		int n1 = 0;
		int n2 = 0;
		Calculator cal = new Calculator();
		Scanner sc = new Scanner(System.in);
		int result = 0;
		int errorcount = 0;
		while(true) {
			n1 = 0;
			n2 = 0;
			result = 0;
			
			System.out.println("*****************************************");
			try {
				System.out.println("Enter Number 1 : ");
				n1 = Integer.parseInt(sc.next());		// try --> statement level variables--> scope --> within try --even not a method level scope
				System.out.println("Enter Number 2 : ");
				n2 =  Integer.parseInt(sc.next());
			}catch(InputMismatchException e) {
				System.out.println("Please do enter only Numeric Values..!");
			}catch(NoSuchElementException e) {
				System.out.println("Invalid Value Entered...");
			}catch(NumberFormatException e) {
				System.out.println("Not a number..");
			}
			
			if(index == number1.length) {
				number1  = Arrays.copyOf(number1, number1.length *2);
			}
			
			if(n1>0 && n2>0) {
				result = cal.addition(n1, n2);
				number1[index++] = result;
				errorcount = 0;
			}else {
				//System.out.println("Invalid Values..!");
				errorcount++;
			}
			
			System.out.println("Do you want to Continue : 0/1");
			try {
			int val =  Integer.parseInt(sc.next());
			if(val<=0) {
				break;
			}
			}catch (InputMismatchException e) {
				System.out.println("Please enter valid Choice --> +ve/-ve -- Number..");
			}catch (NumberFormatException e) {
				System.out.println("Not a number..");
			}
			//sc.close();
			if(errorcount == 3) {
				System.out.println("Number of attempt exceed....!");
				break;
			}
		}
		System.out.println("Here are the results : "+Arrays.toString(number1));
	}
}
