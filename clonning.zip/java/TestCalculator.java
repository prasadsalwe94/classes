package com.demo.java;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TestCalculator {

	
	/**
	 * InputMismatchException,NoSuchElementException --> Unchecked --> compiler is not aware -- these events directly occures at runtime
	 * 								unchecked --> always childs of RuntimeException
	 * 								
	 * 
	 * InterruptedException, --> Checked	--> compiler is aware about these conditions/events
	 * 							checked exception are a child of Exception
	 * 
	 * 
	 * 
	 * 			let it checked / unchecked exceptions --. 
	 * 						always occurs at runtime..
	 * 
	 * 
	 * 
	 * @param args
	 */
	public static void main1(String[] args) {
		
		int n1 = 0;
		int n2 = 0;
		Calculator cal = new Calculator(); // to call instance methods from calculator class
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		while(flag) {
			n1 = 0;
			n2 = 0;
			System.out.println("\n"
					+ "1. Addition\n"
					+ "2. Substraction\n"
					+ "3. Division\n"
					+ "4. Multiplication\n"
					+ "5. Double\n"
					+ "6. Exit\n");
			
			//System.out.println("Enter your Choice : ");
			int ch = takeinput(sc,"Enter your Choice : ");
			
			switch (ch) {
				case 1:
					n1 = takeinput(sc,"Enter Number 1 : ");
					n2 = takeinput(sc,"Enter Number 2 :");
					cal.addition(n1, n2);
					break;
				case 2:
					n1 = takeinput(sc,"Enter Number 1 : ");
					n2 = takeinput(sc,"Enter Number 2: ");
					cal.substraction(n1, n2);
					break;
				case 3:
					n1 = takeinput(sc,"Enter Number 1 : ");
					n2 = takeinput(sc,"Enter Number 2 : ");
				try {
					cal.division(n1, n2);
				} catch (InvalidSecondParam e) {
					System.out.println(e.getMessage());
				}
					break;
				case 4:
					n1 = takeinput(sc,"Enter Number 1 :");
					n2 = takeinput(sc,"Enter Number 2 :");
					cal.multiplication(n1, n2);
					break;
				case 5:
					n1 = takeinput(sc,"Enter Number :");
					cal.doubles(n1);
					break;
				case 6:
					flag = false;
					break;
				default:
					System.out.println("Invalid Choice...try again...!");
					break;
			}
		}
	}

	private static int takeinput(Scanner sc,String message) {
		int val = 0;
		try {
			System.out.println(message);
			val =  Integer.parseInt(sc.next());
			return val;
		}catch (NumberFormatException e) {
			System.out.println("Enter only Number..!");
		}
		
		return val;
		
	}
}
