package com.java.inquries.beans;

public class Professor extends Users{
	static private String roleName = "Trainer";
	private int yearsOfExp;
	public Professor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Professor(int userId, String firstName, String lastName, String email, String gender, Address address,
			long contactNumber, String username, String password, String confirmPassword, int[] courses) {
		super(userId, firstName, lastName, email, gender, address, contactNumber, username, password, confirmPassword, courses);
		// TODO Auto-generated constructor stub
	}
	public Professor(int userId, String firstName, String lastName, String email, String gender, Address address,
			long contactNumber, String username, String password, String confirmPassword, int[] courses,
			int yearsOfExp) {
		super(userId, firstName, lastName, email, gender, address, contactNumber, username, password, confirmPassword,
				courses);
		this.yearsOfExp = yearsOfExp;
	}
	public static String getRoleName() {
		return roleName;
	}
	public static void setRoleName(String roleName) {
		Professor.roleName = roleName;
	}
	public int getYearsOfExp() {
		return yearsOfExp;
	}
	public void setYearsOfExp(int yearsOfExp) {
		this.yearsOfExp = yearsOfExp;
	}
	@Override
	public String toString() {
		return "Professor [yearsOfExp=" + yearsOfExp + "]" +super.toString();
	}
	
	
}
