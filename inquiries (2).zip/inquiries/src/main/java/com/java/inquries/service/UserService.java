package com.java.inquries.service;

import com.java.inquries.beans.Student;

public interface UserService {
	
	public String registerUser(Student student);
}
