package com.java.inquries.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.inquries.beans.Role;

@Controller
@RequestMapping("/role")
public class RoleController {

	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public ModelAndView getRolePage() {
		return new ModelAndView("role");
	}
	
	@RequestMapping(value = "/",method = RequestMethod.POST)
	public ModelAndView saveOrUpdateRole(@ModelAttribute("roleBean") Role bean) {
		return new ModelAndView("role");
	}
	
	@RequestMapping(value = "/edit/{rid}",method = RequestMethod.GET)
	public ModelAndView fetchForEdit(@PathVariable("rid") int rid) {
		return new ModelAndView("role");
	}
	
	@RequestMapping(value = "/delete/{rid}",method = RequestMethod.GET)
	public ModelAndView deleteRole(@PathVariable("rid") int rid) {
		return new ModelAndView("role");
	}
}