package com.java.inquries.dao;

import com.java.inquries.entities.UserEntity;

public interface UserDao {
	public String addNewUser(UserEntity entity);
}
