package com.java.inquries.beans;

public class Student extends Users{
	static private String roleName = "STUDENT";
	private String collegeName;
	private String graduation;
	private int passYear;
	public Student(int userId, String firstName, String lastName, String email, String gender, Address address,
			long contactNumber, String username, String password, String confirmPassword, int[] courses,
			String collegeName, String graduation, int passYear) {
		super(userId, firstName, lastName, email, gender, address, contactNumber, username, password, confirmPassword,
				courses);
		this.collegeName = collegeName;
		this.graduation = graduation;
		this.passYear = passYear;
	}
	@Override
	public String toString() {
		return "Student [collegeName=" + collegeName + ", graduation=" + graduation + ", passYear=" + passYear + "]"  + super.toString();
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int userId, String firstName, String lastName, String email, String gender, Address address,
			long contactNumber, String username, String password, String confirmPassword, int[] courses) {
		super(userId, firstName, lastName, email, gender, address, contactNumber, username, password, confirmPassword, courses);
		// TODO Auto-generated constructor stub
	}
	public static String getRoleName() {
		return roleName;
	}
	public static void setRoleName(String roleName) {
		Student.roleName = roleName;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	public int getPassYear() {
		return passYear;
	}
	public void setPassYear(int passYear) {
		this.passYear = passYear;
	}
	
	
}
