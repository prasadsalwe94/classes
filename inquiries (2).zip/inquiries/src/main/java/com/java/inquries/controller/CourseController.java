package com.java.inquries.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.inquries.beans.Course;

@Controller
@RequestMapping("/courses")
public class CourseController {

	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public ModelAndView getCoursePage() {
		return new ModelAndView("course");
	}
	
	@RequestMapping(value = "/save",method = RequestMethod.POST)
	public ModelAndView saveOrUpdateCourse(@ModelAttribute("crBean") Course bean) {
		return new ModelAndView("course");
	}
	
	@RequestMapping(value = "/edit/{cid}",method = RequestMethod.GET)
	public ModelAndView fetchForEdit(@PathVariable("cid") int cid) {
		return new ModelAndView("course");
	}
	
	@RequestMapping(value = "/delete/{cid}",method = RequestMethod.GET)
	public ModelAndView deleteCourse(@PathVariable("cid") int cid) {
		return new ModelAndView("course");
	}
}