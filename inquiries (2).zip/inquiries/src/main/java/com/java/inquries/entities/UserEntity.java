package com.java.inquries.entities;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "USER_MASTER")
public class UserEntity {
	@Id
	private int userId;
	private String firstName;
	private String lastName;
	private String email;
	private String gender;
	private long contactNumber;
	private String username;
	private String password;
	
	private boolean active;
    private String createdBy;
    private String updatedBy;
    @CreationTimestamp
    private LocalDateTime createdOn;
    @UpdateTimestamp
    private LocalDateTime updatedOn;
    
    
    @ManyToMany
    @JoinTable(
            name = "USER_ROLE_INFO",
            joinColumns = @JoinColumn(
                    name = "USER_ID",
                    referencedColumnName = "userId"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "ROLE_ID",
                    referencedColumnName = "roleId"
            )
    )
    private List<RoleEntity> rolesList;
    
    
    @ManyToMany
    @JoinTable(
            name = "USER_ADDRESS_INFO",
            joinColumns = @JoinColumn(
                    name = "USER_ID",
                    referencedColumnName = "userId"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "ADDRESS_ID",
                    referencedColumnName = "addressId"
            )
    )
    private List<AddressEntity> addressList;


	public UserEntity(int userId, String firstName, String lastName, String email, String gender, long contactNumber,
			String username, String password, boolean active,
			String createdBy, String updatedBy,
			List<RoleEntity> rolesList,
			List<AddressEntity> addressList) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.username = username;
		this.password = password;
		this.active = active;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		//this.createdOn = createdOn;
		//this.updatedOn = updatedOn;
		this.rolesList = rolesList;
		this.addressList = addressList;
	}


	public UserEntity() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "UserEntity [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + ", gender=" + gender + ", contactNumber=" + contactNumber + ", username=" + username
				+ ", password=" + password + ", active=" + active + ", createdBy=" + createdBy + ", updatedBy="
				+ updatedBy + ", createdOn=" + createdOn + ", updatedOn=" + updatedOn + ", rolesList=" + rolesList
				+ ", addressList=" + addressList + "]";
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public long getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public boolean isActive() {
		return active;
	}


	public void setActive(boolean active) {
		this.active = active;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}


	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}

	public List<RoleEntity> getRolesList() {
		return rolesList;
	}


	public void setRolesList(List<RoleEntity> rolesList) {
		this.rolesList = rolesList;
	}


	public List<AddressEntity> getAddressList() {
		return addressList;
	}


	public void setAddressList(List<AddressEntity> addressList) {
		this.addressList = addressList;
	}
    
    
    
    
    
}
