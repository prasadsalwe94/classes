package com.java.inquries.controller;

import java.util.HashMap;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.inquries.beans.Login;

@Controller
@RequestMapping("/login")
public class LoginController {

	@RequestMapping(value = "/authenticate",method = RequestMethod.POST)
	public ModelAndView validateUserCredentails(@ModelAttribute("loginBean") Login login) {
		System.out.println("Login "+login);
		System.out.println("validateUserCredentails");
		HashMap<String,Object> model = new HashMap<String, Object>();
		model.put("loginBean", new Login());
		return new ModelAndView("index",model);
	
	}
	
}
