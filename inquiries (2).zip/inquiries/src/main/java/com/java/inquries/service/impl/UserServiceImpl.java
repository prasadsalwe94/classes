package com.java.inquries.service.impl;

import java.util.ArrayList;
import java.util.Base64;

import javax.management.relation.RoleList;

import org.springframework.stereotype.Service;

import com.java.inquries.beans.Student;
import com.java.inquries.entities.AddressEntity;
import com.java.inquries.entities.RoleEntity;
import com.java.inquries.entities.UserEntity;
import com.java.inquries.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	
	
	@Override
	public String registerUser(Student student) {
		
		UserEntity entity = beanToEntity(student);
		
		
		return null;
	}

	private UserEntity beanToEntity(Student bean) {
		UserEntity entity = new UserEntity();
		entity.setContactNumber(bean.getContactNumber());
		entity.setEmail(bean.getEmail());
		entity.setLastName(bean.getLastName());
		entity.setFirstName(bean.getFirstName());
		entity.setGender(bean.getGender());
		entity.setUserId(bean.getUserId());
		entity.setUsername(bean.getUsername());
		String encodedPwd = Base64.getEncoder().encodeToString(bean.getPassword().getBytes());
		entity.setPassword(encodedPwd);
		
		// RoleDoa-->Role role getRoleByName("Student")
		
		ArrayList<RoleEntity> roleList = new ArrayList<RoleEntity>();
		roleList.add(new RoleEntity(101,"STUDENT"));
		
		ArrayList<AddressEntity> adrList = new ArrayList<AddressEntity>();
		adrList.add(new AddressEntity(101,"Pune","MH",128922));
		
		return entity;
	}

	
	public static void main(String[] args) {
		String encodedPwd = Base64.getEncoder().encodeToString("yogesh123".getBytes());
		System.out.println("EncodedPassword : " +encodedPwd);
		
		byte[] decodedBytes = Base64.getDecoder().decode(encodedPwd);
		String decodedString = new String(decodedBytes);
		System.out.println("Decoded Password : "+decodedString);
	}
	
}
