package com.java.inquries.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.inquries.beans.Student;
import com.java.inquries.beans.Users;
import com.java.inquries.service.impl.UserServiceImpl;

@Controller
@RequestMapping("/users")
public class UserController {

	@Autowired
	UserServiceImpl service;
	
	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public ModelAndView getUserPage() {
		System.out.println("Inside get User Page...");
		HashMap<String,Object> model = new HashMap<String, Object>();
		model.put("userBean", new Student());
		return new ModelAndView("register",model);
	}
	
	@RequestMapping(value = "/save",method = RequestMethod.POST)
	public ModelAndView saveOrUpdateUser(@ModelAttribute("userBean") Student bean) {
		HashMap<String,Object> model = new HashMap<String, Object>();
		model.put("userBean", new Student());
		System.out.println("Entered Data --> "+bean);
		
		String errorMessage = "";
		if(bean!=null) {
			if(!bean.getPassword().equals(bean.getConfirmPassword())) {
				errorMessage = "Password and Confirm Passwords Not Matching..!";
			}else if(bean.getUsername().length()<=5) {
				errorMessage = "Invalid UserName..!";
			}else {
				service.registerUser(bean);
			}
		}
		
		return  new ModelAndView("register",model);
	}
	
	@RequestMapping(value = "/edit/{uid}",method = RequestMethod.GET)
	public ModelAndView fetchForEdit(@PathVariable("uid") int uid) {
		HashMap<String,Object> model = new HashMap<String, Object>();
		model.put("userBean", new Student());
		return  new ModelAndView("register",model);
	}
	
	@RequestMapping(value = "/delete/{uid}",method = RequestMethod.GET)
	public ModelAndView deleteUser(@PathVariable("uid") int uid) {
		HashMap<String,Object> model = new HashMap<String, Object>();
		model.put("userBean", new Student());
		return new ModelAndView("register",model);
	}
}