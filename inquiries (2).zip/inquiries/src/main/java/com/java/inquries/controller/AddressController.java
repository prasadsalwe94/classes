package com.java.inquries.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.inquries.beans.Address;

@Controller
@RequestMapping("/address")
public class AddressController {

	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public ModelAndView getAddressPage() {
		return new ModelAndView("address");
	}
	
	@RequestMapping(value = "/",method = RequestMethod.POST)
	public ModelAndView saveOrUpdateAddress(@ModelAttribute("adrBean") Address bean) {
		return new ModelAndView("address");
	}
	
	@RequestMapping(value = "/edit/{aid}",method = RequestMethod.GET)
	public ModelAndView fetchForEdit(@PathVariable("aid") int aid) {
		return new ModelAndView("address");
	}
	
	@RequestMapping(value = "/delete/{aid}",method = RequestMethod.GET)
	public ModelAndView deleteAddress(@PathVariable("aid") int aid) {
		return new ModelAndView("address");
	}
}

