package com.java.inquries.controller;

import java.util.HashMap;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.inquries.beans.Login;
import com.java.inquries.beans.Student;

@Controller
@RequestMapping("/")
public class MainController {
		
	static {
		System.out.println("Main Controller Loaded...");
	}
	
	@RequestMapping(value = "/login",method = RequestMethod.GET)
	public ModelAndView getCoursePage() {
		System.out.println("Inside get User Page...");
		HashMap<String,Object> model = new HashMap<String, Object>();
		model.put("loginBean", new Login());
		return new ModelAndView("index",model);
	}
	
	
	@RequestMapping(value = "/forgot",method = RequestMethod.GET)
	public ModelAndView resetUserPassword() {
		System.out.println("resetUserPassword");
		HashMap<String,Object> model = new HashMap<String, Object>();
		return new ModelAndView("forgot",model);
	}
	
	
	@ModelAttribute("loginBean")
	public Login getLoginBean() {
		return new Login();
	}
	
}
