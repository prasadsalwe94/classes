package com.java.inquries.dao.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.java.inquries.beans.Student;
import com.java.inquries.dao.UserDao;
import com.java.inquries.entities.UserEntity;
import com.java.inquries.service.UserService;

@Repository
public class UserDaoImpl implements UserDao {
	
	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public String addNewUser(UserEntity entity) {
		return null;
	}
//rolemaster --> coursemaster ----> Girls
// addressmaster ---> registermater --> boys
// loginController --->
	


		// u are going to write a code--> to save the userentity---
		// user + role + address..
	
	
	
	
}
