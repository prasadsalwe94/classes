package com.java.inquries.beans;

import java.util.Arrays;

public class Users {
	private int userId;
	private String firstName;
	private String lastName;
	private String email;
	private String gender;
	private Address address;
	private long contactNumber;
	private String username;
	private String password;
	private String confirmPassword;
	private int[] courses;
	public Users(int userId, String firstName, String lastName, String email, String gender, Address address,
			long contactNumber, String username, String password, String confirmPassword, int[] courses) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.gender = gender;
		this.address = address;
		this.contactNumber = contactNumber;
		this.username = username;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.courses = courses;
	}
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public int[] getCourses() {
		return courses;
	}
	public void setCourses(int[] courses) {
		this.courses = courses;
	}
	@Override
	public String toString() {
		return "Users [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", gender=" + gender + ", address=" + address + ", contactNumber=" + contactNumber + ", username="
				+ username + ", password=" + password + ", confirmPassword=" + confirmPassword + ", courses="
				+ Arrays.toString(courses) + "]";
	}
	
	
	
}
