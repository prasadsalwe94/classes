package com.java.inquries.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.java.inquries.service.impl.StudentServiceImpl;

@Controller("stud_controller")
public class StudentController {
	static {
		System.out.println("SpringConfiguration loaded..");
	}
	
	@Autowired
	public StudentServiceImpl service;
	
}
