package com.java.inquries.dao;

public interface StudentDao {

}
